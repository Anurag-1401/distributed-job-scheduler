"""
Concurrency correctness tests.

These tests prove that multiple workers polling the SAME queue concurrently
can never claim the SAME job, using real overlapping PostgreSQL transactions
(SQLite cannot meaningfully exercise `FOR UPDATE SKIP LOCKED` under
concurrent writers, since it serializes at the database-file level).

Requires a running PostgreSQL instance. Set TEST_DATABASE_URL, e.g.:

    export TEST_DATABASE_URL=postgresql+asyncpg://scheduler:scheduler@localhost:5432/scheduler_test

If not set, these tests are skipped (they still run automatically in CI via
docker-compose, see docker-compose.yml's `test` service).
"""
import asyncio
import os
import uuid
from datetime import datetime, timezone

import pytest
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine

from app.models import Base
from app.models.enums import JobStatus, JobType, QueueStatus
from app.models.job import Job
from app.models.organization import Organization
from app.models.organization_member import OrganizationMember
from app.models.project import Project
from app.models.queue import Queue
from app.models.user import User
from app.models.worker import Worker, WorkerStatus
from app.repositories.job_repo import JobRepository

TEST_DATABASE_URL = os.environ.get("TEST_DATABASE_URL")

pytestmark = pytest.mark.skipif(
    not TEST_DATABASE_URL, reason="TEST_DATABASE_URL not set; concurrency tests require real PostgreSQL"
)


@pytest.fixture
async def pg_engine():
    engine = create_async_engine(TEST_DATABASE_URL, pool_size=20, max_overflow=20)
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.drop_all)
        await conn.run_sync(Base.metadata.create_all)
    yield engine
    await engine.dispose()


async def _seed_queue_with_jobs(engine, job_count: int) -> uuid.UUID:
    session_maker = async_sessionmaker(bind=engine, expire_on_commit=False, class_=AsyncSession)
    async with session_maker() as session:
        org = Organization(name="ConcurrencyOrg")
        session.add(org)
        await session.flush()
        project = Project(organization_id=org.id, name="ConcurrencyProject")
        session.add(project)
        await session.flush()
        queue = Queue(project_id=project.id, name="concurrency-queue", status=QueueStatus.ACTIVE, concurrency_limit=1000)
        session.add(queue)
        await session.flush()

        now = datetime.now(timezone.utc)
        for i in range(job_count):
            job = Job(
                queue_id=queue.id, job_type=JobType.IMMEDIATE, task_name="echo", payload={"i": i},
                priority=0, status=JobStatus.QUEUED, scheduled_at=now, max_attempts=3,
            )
            session.add(job)
        await session.commit()
        return queue.id


async def _worker_claim_loop(engine, queue_id: uuid.UUID, worker_id: uuid.UUID, claimed_ids: list, attempts: int):
    """Repeatedly attempts to claim a job, simulating one worker's poll loop."""
    session_maker = async_sessionmaker(bind=engine, expire_on_commit=False, class_=AsyncSession)
    for _ in range(attempts):
        async with session_maker() as session:
            repo = JobRepository(session)
            job = await repo.claim_next_job(queue_id=queue_id, worker_id=worker_id, lease_seconds=60)
            if job is not None:
                await session.commit()
                claimed_ids.append(job.id)
            else:
                await session.rollback()


async def test_concurrent_workers_never_claim_same_job(pg_engine):
    """
    The single most important correctness test in this system: spin up N
    simulated workers hammering `claim_next_job` concurrently against a
    shared pool of jobs, then assert that every claimed job id is unique
    (no double-claims) and that the total number of claims never exceeds
    the number of jobs available.
    """
    job_count = 50
    worker_count = 10
    queue_id = await _seed_queue_with_jobs(pg_engine, job_count)

    claimed_ids: list[uuid.UUID] = []
    workers = [uuid.uuid4() for _ in range(worker_count)]

    # Register worker rows (not strictly required by claim_next_job, but
    # realistic and required by the worker_id FK).
    session_maker = async_sessionmaker(bind=pg_engine, expire_on_commit=False, class_=AsyncSession)
    async with session_maker() as session:
        now = datetime.now(timezone.utc)
        for wid in workers:
            session.add(Worker(id=wid, worker_key=str(wid), status=WorkerStatus.ONLINE, registered_at=now))
        await session.commit()

    all_claimed_lists = [[] for _ in workers]

    await asyncio.gather(*[
        _worker_claim_loop(pg_engine, queue_id, wid, all_claimed_lists[i], attempts=job_count)
        for i, wid in enumerate(workers)
    ])

    for lst in all_claimed_lists:
        claimed_ids.extend(lst)

    # No job was claimed by more than one worker (no duplicates).
    assert len(claimed_ids) == len(set(claimed_ids)), "A job was claimed more than once by concurrent workers!"

    # Every job in the queue was eventually claimed exactly once.
    assert len(claimed_ids) == job_count


async def test_claim_respects_paused_queue(pg_engine):
    queue_id = await _seed_queue_with_jobs(pg_engine, 5)
    session_maker = async_sessionmaker(bind=pg_engine, expire_on_commit=False, class_=AsyncSession)
    async with session_maker() as session:
        queue = await session.get(Queue, queue_id)
        queue.status = QueueStatus.PAUSED
        await session.commit()

    async with session_maker() as session:
        repo = JobRepository(session)
        job = await repo.claim_next_job(queue_id=queue_id, worker_id=uuid.uuid4(), lease_seconds=60)
        assert job is None


async def test_claim_respects_priority_ordering(pg_engine):
    session_maker = async_sessionmaker(bind=pg_engine, expire_on_commit=False, class_=AsyncSession)
    async with session_maker() as session:
        org = Organization(name="PriorityOrg")
        session.add(org)
        await session.flush()
        project = Project(organization_id=org.id, name="PriorityProject")
        session.add(project)
        await session.flush()
        queue = Queue(project_id=project.id, name="priority-queue", status=QueueStatus.ACTIVE, concurrency_limit=10)
        session.add(queue)
        await session.flush()

        now = datetime.now(timezone.utc)
        low = Job(queue_id=queue.id, job_type=JobType.IMMEDIATE, task_name="echo", payload={}, priority=1, status=JobStatus.QUEUED, scheduled_at=now, max_attempts=3)
        high = Job(queue_id=queue.id, job_type=JobType.IMMEDIATE, task_name="echo", payload={}, priority=10, status=JobStatus.QUEUED, scheduled_at=now, max_attempts=3)
        session.add_all([low, high])
        await session.commit()
        queue_id, high_id = queue.id, high.id

    async with session_maker() as session:
        repo = JobRepository(session)
        job = await repo.claim_next_job(queue_id=queue_id, worker_id=uuid.uuid4(), lease_seconds=60)
        await session.commit()
        assert job.id == high_id, "Higher-priority job should be claimed first"
