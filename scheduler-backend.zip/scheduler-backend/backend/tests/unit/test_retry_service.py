import pytest

from app.models.enums import RetryBackoffStrategy
from app.services.retry_service import compute_backoff_seconds


def test_fixed_backoff_is_constant():
    for attempt in (1, 2, 3, 4):
        delay = compute_backoff_seconds(
            strategy=RetryBackoffStrategy.FIXED, attempt_number=attempt,
            base_delay_seconds=10, max_delay_seconds=1000, jitter=False,
        )
        assert delay == 10


def test_linear_backoff_grows_linearly():
    delays = [
        compute_backoff_seconds(
            strategy=RetryBackoffStrategy.LINEAR, attempt_number=n,
            base_delay_seconds=10, max_delay_seconds=1000, jitter=False,
        )
        for n in (1, 2, 3, 4)
    ]
    assert delays == [10, 20, 30, 40]


def test_exponential_backoff_doubles():
    delays = [
        compute_backoff_seconds(
            strategy=RetryBackoffStrategy.EXPONENTIAL, attempt_number=n,
            base_delay_seconds=2, max_delay_seconds=1000, jitter=False,
        )
        for n in (1, 2, 3, 4)
    ]
    assert delays == [2, 4, 8, 16]


def test_backoff_respects_max_delay_cap():
    delay = compute_backoff_seconds(
        strategy=RetryBackoffStrategy.EXPONENTIAL, attempt_number=10,
        base_delay_seconds=2, max_delay_seconds=50, jitter=False,
    )
    assert delay == 50


def test_jitter_stays_within_reasonable_bounds():
    base = 100
    for _ in range(50):
        delay = compute_backoff_seconds(
            strategy=RetryBackoffStrategy.FIXED, attempt_number=1,
            base_delay_seconds=base, max_delay_seconds=1000, jitter=True,
        )
        assert 0 <= delay <= base * 1.25
