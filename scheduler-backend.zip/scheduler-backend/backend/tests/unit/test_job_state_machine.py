import uuid
from datetime import datetime, timezone

import pytest

from app.core.exceptions import InvalidStateTransitionError
from app.models.enums import JobStatus, JobType
from app.models.job import Job
from app.services.job_service import transition_job_status


def make_job(status: JobStatus) -> Job:
    return Job(
        id=uuid.uuid4(), queue_id=uuid.uuid4(), job_type=JobType.IMMEDIATE,
        task_name="echo", payload={}, priority=0, status=status,
        scheduled_at=datetime.now(timezone.utc), max_attempts=3, attempt_count=0,
    )


def test_valid_transition_queued_to_claimed():
    job = make_job(JobStatus.QUEUED)
    transition_job_status(job, JobStatus.CLAIMED)
    assert job.status == JobStatus.CLAIMED


def test_valid_transition_running_to_completed():
    job = make_job(JobStatus.RUNNING)
    transition_job_status(job, JobStatus.COMPLETED)
    assert job.status == JobStatus.COMPLETED


def test_invalid_transition_completed_to_running_raises():
    job = make_job(JobStatus.COMPLETED)
    with pytest.raises(InvalidStateTransitionError):
        transition_job_status(job, JobStatus.RUNNING)


def test_invalid_transition_queued_to_completed_raises():
    job = make_job(JobStatus.QUEUED)
    with pytest.raises(InvalidStateTransitionError):
        transition_job_status(job, JobStatus.COMPLETED)


def test_dead_letter_can_be_manually_retried():
    job = make_job(JobStatus.DEAD_LETTER)
    transition_job_status(job, JobStatus.QUEUED)
    assert job.status == JobStatus.QUEUED


def test_cancelled_is_terminal():
    job = make_job(JobStatus.CANCELLED)
    with pytest.raises(InvalidStateTransitionError):
        transition_job_status(job, JobStatus.QUEUED)
