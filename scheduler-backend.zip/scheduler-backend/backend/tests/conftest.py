"""
Test configuration.

Fast unit/integration tests run against an in-memory-ish SQLite database
(via aiosqlite) for speed and CI-friendliness -- the GUID type decorator
in app.db.base makes models portable across dialects.

The concurrency tests that prove atomic job claiming under real concurrent
transactions REQUIRE PostgreSQL (SQLite does not support `FOR UPDATE SKIP
LOCKED` semantics under concurrent writers the same way). Those tests read
TEST_DATABASE_URL from the environment and are skipped automatically if it
is not set to a postgres+asyncpg URL. See tests/concurrency/test_atomic_claim.py.
"""
import asyncio
import uuid
from datetime import datetime, timezone

import pytest
import pytest_asyncio
from httpx import AsyncClient, ASGITransport
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine
from sqlalchemy.pool import StaticPool

from app.core.security import create_access_token, hash_password
from app.db.session import get_db
from app.models import Base
from app.models.enums import OrgRole
from app.models.organization import Organization
from app.models.organization_member import OrganizationMember
from app.models.project import Project
from app.models.queue import Queue
from app.models.user import User


@pytest_asyncio.fixture
async def engine():
    engine = create_async_engine(
        "sqlite+aiosqlite:///:memory:",
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    yield engine
    await engine.dispose()


@pytest_asyncio.fixture
async def db_session(engine) -> AsyncSession:
    session_maker = async_sessionmaker(bind=engine, expire_on_commit=False, class_=AsyncSession)
    async with session_maker() as session:
        yield session


@pytest_asyncio.fixture
async def app_client(engine):
    from app.main import app

    session_maker = async_sessionmaker(bind=engine, expire_on_commit=False, class_=AsyncSession)

    async def override_get_db():
        async with session_maker() as session:
            yield session

    app.dependency_overrides[get_db] = override_get_db
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as client:
        yield client
    app.dependency_overrides.clear()


@pytest_asyncio.fixture
async def seeded_context(db_session: AsyncSession):
    """Creates a user, organization, project, and queue; returns auth header + ids."""
    user = User(email="test@example.com", password_hash=hash_password("password123"), name="Test User")
    db_session.add(user)
    await db_session.flush()

    org = Organization(name="Acme Corp")
    db_session.add(org)
    await db_session.flush()

    membership = OrganizationMember(organization_id=org.id, user_id=user.id, role=OrgRole.OWNER)
    db_session.add(membership)

    project = Project(organization_id=org.id, name="Test Project")
    db_session.add(project)
    await db_session.flush()

    queue = Queue(project_id=project.id, name="default", priority=0, concurrency_limit=5)
    db_session.add(queue)
    await db_session.commit()

    token = create_access_token(subject=user.id)
    return {
        "user": user,
        "organization": org,
        "project": project,
        "queue": queue,
        "token": token,
        "headers": {"Authorization": f"Bearer {token}"},
    }
