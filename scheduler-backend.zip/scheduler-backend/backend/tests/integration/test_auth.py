import pytest


async def test_register_and_login(app_client):
    resp = await app_client.post("/api/v1/auth/register", json={
        "email": "alice@example.com", "password": "supersecret1", "name": "Alice",
    })
    assert resp.status_code == 201
    body = resp.json()
    assert body["user"]["email"] == "alice@example.com"
    assert "access_token" in body

    resp = await app_client.post("/api/v1/auth/login", json={
        "email": "alice@example.com", "password": "supersecret1",
    })
    assert resp.status_code == 200
    assert resp.json()["user"]["email"] == "alice@example.com"


async def test_login_invalid_credentials(app_client):
    await app_client.post("/api/v1/auth/register", json={
        "email": "bob@example.com", "password": "supersecret1", "name": "Bob",
    })
    resp = await app_client.post("/api/v1/auth/login", json={
        "email": "bob@example.com", "password": "wrongpassword",
    })
    assert resp.status_code == 401
    assert resp.json()["error"]["code"] == "INVALID_CREDENTIALS"


async def test_duplicate_registration_conflicts(app_client):
    payload = {"email": "carol@example.com", "password": "supersecret1", "name": "Carol"}
    r1 = await app_client.post("/api/v1/auth/register", json=payload)
    assert r1.status_code == 201
    r2 = await app_client.post("/api/v1/auth/register", json=payload)
    assert r2.status_code == 409


async def test_me_requires_token(app_client):
    resp = await app_client.get("/api/v1/auth/me")
    assert resp.status_code == 401


async def test_me_with_valid_token(app_client):
    reg = await app_client.post("/api/v1/auth/register", json={
        "email": "dave@example.com", "password": "supersecret1", "name": "Dave",
    })
    token = reg.json()["access_token"]
    resp = await app_client.get("/api/v1/auth/me", headers={"Authorization": f"Bearer {token}"})
    assert resp.status_code == 200
    assert resp.json()["email"] == "dave@example.com"
