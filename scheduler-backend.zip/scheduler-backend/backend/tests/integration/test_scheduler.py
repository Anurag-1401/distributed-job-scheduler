from datetime import datetime, timezone

import pytest

from app.scheduler.engine import compute_next_run


def test_compute_next_run_every_minute():
    base = datetime(2026, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
    next_run = compute_next_run("* * * * *", base)
    assert next_run == datetime(2026, 1, 1, 12, 1, 0, tzinfo=timezone.utc)


def test_compute_next_run_daily():
    base = datetime(2026, 1, 1, 23, 30, 0, tzinfo=timezone.utc)
    next_run = compute_next_run("0 0 * * *", base)
    assert next_run == datetime(2026, 1, 2, 0, 0, 0, tzinfo=timezone.utc)


async def test_scheduled_job_creation_via_api(app_client, seeded_context):
    headers = seeded_context["headers"]
    queue_id = str(seeded_context["queue"].id)

    resp = await app_client.post("/api/v1/scheduled-jobs", json={
        "queue_id": queue_id, "task_name": "echo", "cron_expression": "*/5 * * * *",
    }, headers=headers)
    assert resp.status_code == 201
    body = resp.json()
    assert body["enabled"] is True
    assert body["next_run_at"] is not None


async def test_fire_due_scheduled_jobs_is_idempotent(db_session, seeded_context):
    from app.models.scheduled_job import ScheduledJob
    from app.scheduler.engine import SchedulerEngine
    from app.repositories.job_repo import JobRepository
    from datetime import timedelta

    queue = seeded_context["queue"]
    sj = ScheduledJob(
        queue_id=queue.id, task_name="echo", payload={}, cron_expression="* * * * *",
        next_run_at=datetime.now(timezone.utc) - timedelta(minutes=1), enabled=True,
    )
    db_session.add(sj)
    await db_session.commit()

    # Simulate firing by directly invoking the same logic against this session.
    from app.repositories.scheduled_job_repo import ScheduledJobRepository
    from app.models.job import Job
    from app.models.enums import JobStatus, JobType

    sched_repo = ScheduledJobRepository(db_session)
    job_repo = JobRepository(db_session)

    due = await sched_repo.find_due(limit=10)
    assert len(due) == 1

    fire_key = f"cron:{sj.id}:{sj.next_run_at.isoformat()}"
    existing = await job_repo.get_by_idempotency_key(sj.queue_id, fire_key)
    assert existing is None

    job = Job(
        queue_id=sj.queue_id, job_type=JobType.RECURRING, task_name=sj.task_name, payload={},
        priority=0, status=JobStatus.QUEUED, scheduled_at=sj.next_run_at, max_attempts=3,
        idempotency_key=fire_key, scheduled_job_id=sj.id,
    )
    db_session.add(job)
    await db_session.commit()

    # Firing again with the SAME key must not create a duplicate job.
    existing_again = await job_repo.get_by_idempotency_key(sj.queue_id, fire_key)
    assert existing_again is not None
    assert existing_again.id == job.id
