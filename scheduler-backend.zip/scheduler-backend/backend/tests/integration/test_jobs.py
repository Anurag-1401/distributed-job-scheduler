import pytest


async def test_create_immediate_job(app_client, seeded_context):
    headers = seeded_context["headers"]
    queue_id = str(seeded_context["queue"].id)

    resp = await app_client.post("/api/v1/jobs", json={
        "queue_id": queue_id, "job_type": "IMMEDIATE", "task_name": "echo", "payload": {"x": 1},
    }, headers=headers)
    assert resp.status_code == 201
    job = resp.json()
    assert job["status"] == "QUEUED"
    assert job["job_type"] == "IMMEDIATE"


async def test_create_delayed_job_requires_delay(app_client, seeded_context):
    headers = seeded_context["headers"]
    queue_id = str(seeded_context["queue"].id)

    resp = await app_client.post("/api/v1/jobs", json={
        "queue_id": queue_id, "job_type": "DELAYED", "task_name": "echo",
    }, headers=headers)
    assert resp.status_code == 422


async def test_create_delayed_job_success(app_client, seeded_context):
    headers = seeded_context["headers"]
    queue_id = str(seeded_context["queue"].id)

    resp = await app_client.post("/api/v1/jobs", json={
        "queue_id": queue_id, "job_type": "DELAYED", "task_name": "echo", "delay_seconds": 30,
    }, headers=headers)
    assert resp.status_code == 201


async def test_idempotency_key_prevents_duplicate_job(app_client, seeded_context):
    headers = seeded_context["headers"]
    queue_id = str(seeded_context["queue"].id)
    payload = {
        "queue_id": queue_id, "job_type": "IMMEDIATE", "task_name": "echo",
        "idempotency_key": "order-123-charge",
    }

    r1 = await app_client.post("/api/v1/jobs", json=payload, headers=headers)
    r2 = await app_client.post("/api/v1/jobs", json=payload, headers=headers)

    assert r1.status_code == 201
    assert r2.status_code == 201
    assert r1.json()["id"] == r2.json()["id"]


async def test_batch_job_creation_and_progress(app_client, seeded_context):
    headers = seeded_context["headers"]
    queue_id = str(seeded_context["queue"].id)

    resp = await app_client.post("/api/v1/jobs/batch", json={
        "queue_id": queue_id,
        "jobs": [{"task_name": "echo", "payload": {"i": i}} for i in range(5)],
    }, headers=headers)
    assert resp.status_code == 201
    jobs = resp.json()
    batch_root = jobs[0]
    assert batch_root["job_type"] == "BATCH"
    assert len(jobs) == 6  # root + 5 children

    progress_resp = await app_client.get(f"/api/v1/jobs/{batch_root['id']}/batch-progress", headers=headers)
    assert progress_resp.status_code == 200
    progress = progress_resp.json()
    assert progress["total"] == 5
    assert progress["queued"] == 5


async def test_list_jobs_pagination(app_client, seeded_context):
    headers = seeded_context["headers"]
    queue_id = str(seeded_context["queue"].id)
    for i in range(3):
        await app_client.post("/api/v1/jobs", json={
            "queue_id": queue_id, "job_type": "IMMEDIATE", "task_name": "echo", "payload": {"i": i},
        }, headers=headers)

    resp = await app_client.get(f"/api/v1/jobs?queue_id={queue_id}&limit=2&page=1", headers=headers)
    assert resp.status_code == 200
    page = resp.json()
    assert page["total"] == 3
    assert len(page["items"]) == 2
    assert page["pages"] == 2
