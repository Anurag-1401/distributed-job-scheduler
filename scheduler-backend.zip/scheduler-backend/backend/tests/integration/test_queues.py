import pytest


async def test_create_queue_and_pause_resume(app_client, seeded_context):
    headers = seeded_context["headers"]
    project_id = str(seeded_context["project"].id)

    resp = await app_client.post("/api/v1/queues", json={
        "project_id": project_id, "name": "emails", "priority": 5, "concurrency_limit": 3,
    }, headers=headers)
    assert resp.status_code == 201
    queue = resp.json()
    assert queue["status"] == "ACTIVE"

    resp = await app_client.post(f"/api/v1/queues/{queue['id']}/pause", headers=headers)
    assert resp.status_code == 200
    assert resp.json()["status"] == "PAUSED"

    resp = await app_client.post(f"/api/v1/queues/{queue['id']}/resume", headers=headers)
    assert resp.status_code == 200
    assert resp.json()["status"] == "ACTIVE"


async def test_duplicate_queue_name_in_project_conflicts(app_client, seeded_context):
    headers = seeded_context["headers"]
    project_id = str(seeded_context["project"].id)
    payload = {"project_id": project_id, "name": "dupe-queue"}

    r1 = await app_client.post("/api/v1/queues", json=payload, headers=headers)
    assert r1.status_code == 201

    r2 = await app_client.post("/api/v1/queues", json=payload, headers=headers)
    assert r2.status_code >= 400
