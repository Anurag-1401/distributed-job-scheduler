import asyncio
from datetime import datetime, timedelta, timezone

import pytest


async def test_worker_register_and_heartbeat(app_client, seeded_context):
    headers = seeded_context["headers"]

    resp = await app_client.post("/api/v1/workers/register", json={"worker_key": "worker-1", "hostname": "host-a"}, headers=headers)
    assert resp.status_code == 201
    worker = resp.json()
    assert worker["status"] == "ONLINE"

    hb_resp = await app_client.post(
        f"/api/v1/workers/{worker['id']}/heartbeat",
        json={"status": "ONLINE", "current_job_count": 2},
        headers=headers,
    )
    assert hb_resp.status_code == 200

    list_resp = await app_client.get("/api/v1/workers", headers=headers)
    assert list_resp.status_code == 200
    workers = list_resp.json()
    match = next(w for w in workers if w["worker_key"] == "worker-1")
    assert match["is_healthy"] is True


async def test_stale_worker_marked_unhealthy(db_session, seeded_context):
    from app.models.worker import Worker
    from app.models.enums import WorkerStatus
    from app.repositories.worker_repo import WorkerRepository
    from app.core.config import settings

    stale_worker = Worker(
        worker_key="stale-worker",
        status=WorkerStatus.ONLINE,
        registered_at=datetime.now(timezone.utc) - timedelta(hours=1),
        last_heartbeat_at=datetime.now(timezone.utc) - timedelta(hours=1),
    )
    db_session.add(stale_worker)
    await db_session.commit()

    is_healthy = WorkerRepository.is_healthy(stale_worker, settings.WORKER_HEARTBEAT_TIMEOUT_SECONDS)
    assert is_healthy is False
