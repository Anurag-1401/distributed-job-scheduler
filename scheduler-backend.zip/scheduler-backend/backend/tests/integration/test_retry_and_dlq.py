import uuid
from datetime import datetime, timezone

import pytest
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.enums import JobStatus, JobType, ExecutionStatus, RetryBackoffStrategy
from app.models.job import Job
from app.models.retry_policy import RetryPolicy
from app.models.worker import Worker, WorkerStatus
from app.repositories.job_repo import JobRepository
from app.repositories.dlq_repo import DeadLetterJobRepository
from app.services.job_service import transition_job_status
from app.services.dlq_service import move_job_to_dead_letter


async def _make_worker(session: AsyncSession) -> Worker:
    worker = Worker(worker_key=f"test-worker-{uuid.uuid4()}", status=WorkerStatus.ONLINE, registered_at=datetime.now(timezone.utc))
    session.add(worker)
    await session.flush()
    return worker


async def test_task_success_completes_job(db_session, seeded_context):
    """Directly exercises the task registry + status transition, simulating
    what WorkerEngine._execute_job does, without needing a live event loop
    worker process."""
    from app.tasks.registry import get_task_handler

    queue = seeded_context["queue"]
    job = Job(
        queue_id=queue.id, job_type=JobType.IMMEDIATE, task_name="echo", payload={"hello": "world"},
        priority=0, status=JobStatus.QUEUED, scheduled_at=datetime.now(timezone.utc), max_attempts=3,
    )
    db_session.add(job)
    await db_session.commit()

    handler = get_task_handler("echo")
    result = await handler(job.payload)
    assert result == {"echoed": {"hello": "world"}}

    transition_job_status(job, JobStatus.CLAIMED)
    transition_job_status(job, JobStatus.RUNNING)
    transition_job_status(job, JobStatus.COMPLETED)
    await db_session.commit()
    assert job.status == JobStatus.COMPLETED


async def test_retry_exhaustion_moves_job_to_dlq(db_session, seeded_context):
    queue = seeded_context["queue"]
    job = Job(
        queue_id=queue.id, job_type=JobType.IMMEDIATE, task_name="always_fails", payload={},
        priority=0, status=JobStatus.QUEUED, scheduled_at=datetime.now(timezone.utc),
        max_attempts=2, attempt_count=2,  # already exhausted
    )
    db_session.add(job)
    await db_session.commit()

    transition_job_status(job, JobStatus.CLAIMED)
    transition_job_status(job, JobStatus.RUNNING)
    transition_job_status(job, JobStatus.FAILED)
    assert job.attempt_count >= job.max_attempts
    transition_job_status(job, JobStatus.DEAD_LETTER)
    entry = await move_job_to_dead_letter(db_session, job, reason="exhausted", final_error="boom")
    await db_session.commit()

    dlq_repo = DeadLetterJobRepository(db_session)
    fetched = await dlq_repo.get_by_job_id(job.id)
    assert fetched is not None
    assert fetched.attempts_made == 2
    assert job.status == JobStatus.DEAD_LETTER


async def test_dlq_retry_requeues_job_via_api(app_client, seeded_context, db_session):
    headers = seeded_context["headers"]
    queue = seeded_context["queue"]

    job = Job(
        queue_id=queue.id, job_type=JobType.IMMEDIATE, task_name="broken", payload={},
        priority=0, status=JobStatus.QUEUED, scheduled_at=datetime.now(timezone.utc),
        max_attempts=1, attempt_count=1,
    )
    db_session.add(job)
    await db_session.flush()
    transition_job_status(job, JobStatus.CLAIMED)
    transition_job_status(job, JobStatus.RUNNING)
    transition_job_status(job, JobStatus.FAILED)
    transition_job_status(job, JobStatus.DEAD_LETTER)
    entry = await move_job_to_dead_letter(db_session, job, reason="exhausted", final_error="boom")
    await db_session.commit()

    resp = await app_client.post(f"/api/v1/dlq/{entry.id}/retry", headers=headers)
    assert resp.status_code == 200

    job_resp = await app_client.get(f"/api/v1/jobs/{job.id}", headers=headers)
    assert job_resp.status_code == 200
    assert job_resp.json()["status"] == "QUEUED"
    assert job_resp.json()["attempt_count"] == 0
