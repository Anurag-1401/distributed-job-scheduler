import pytest


async def register(client, email):
    resp = await client.post("/api/v1/auth/register", json={
        "email": email, "password": "supersecret1", "name": email.split("@")[0],
    })
    body = resp.json()
    return body["access_token"], body["user"]["id"]


async def test_project_isolation_across_organizations(app_client):
    token_a, _ = await register(app_client, "orga_owner@example.com")
    token_b, _ = await register(app_client, "orgb_owner@example.com")

    headers_a = {"Authorization": f"Bearer {token_a}"}
    headers_b = {"Authorization": f"Bearer {token_b}"}

    org_a = (await app_client.post("/api/v1/organizations", json={"name": "Org A"}, headers=headers_a)).json()
    org_b = (await app_client.post("/api/v1/organizations", json={"name": "Org B"}, headers=headers_b)).json()

    project_a = (await app_client.post(
        "/api/v1/projects", json={"organization_id": org_a["id"], "name": "Project A"}, headers=headers_a
    )).json()

    # User B must not be able to access Org A's project.
    resp = await app_client.get(f"/api/v1/projects/{project_a['id']}", headers=headers_b)
    assert resp.status_code == 403

    # User A can access their own project.
    resp = await app_client.get(f"/api/v1/projects/{project_a['id']}", headers=headers_a)
    assert resp.status_code == 200


async def test_organization_membership_required_to_list_projects(app_client):
    token_a, _ = await register(app_client, "listera@example.com")
    token_b, _ = await register(app_client, "listerb@example.com")
    headers_a = {"Authorization": f"Bearer {token_a}"}
    headers_b = {"Authorization": f"Bearer {token_b}"}

    org_a = (await app_client.post("/api/v1/organizations", json={"name": "ListOrg"}, headers=headers_a)).json()

    resp = await app_client.get(f"/api/v1/projects?organization_id={org_a['id']}", headers=headers_b)
    assert resp.status_code == 403
