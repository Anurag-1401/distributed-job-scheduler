import math

from app.schemas.common import Page


def paginate(items: list, total: int, page: int, limit: int) -> Page:
    pages = math.ceil(total / limit) if limit else 0
    return Page(items=items, total=total, page=page, limit=limit, pages=pages)
