"""
Task registry.

Task execution is intentionally sandboxed to a fixed, developer-controlled
registry of Python callables keyed by name (`task_name` on the Job). The API
never accepts or executes arbitrary Python code supplied in a job payload —
only JSON payloads that are passed as arguments to a pre-registered task
function. This prevents remote code execution via the job API.

Add new task types by writing an async function `async def handler(payload: dict) -> dict`
and registering it below.
"""
import asyncio
import random
from typing import Awaitable, Callable

import httpx

TaskHandler = Callable[[dict], Awaitable[dict]]

_REGISTRY: dict[str, TaskHandler] = {}


def register_task(name: str):
    def decorator(fn: TaskHandler) -> TaskHandler:
        _REGISTRY[name] = fn
        return fn
    return decorator


def get_task_handler(name: str) -> TaskHandler:
    if name not in _REGISTRY:
        raise KeyError(f"No task registered with name '{name}'")
    return _REGISTRY[name]


def list_registered_tasks() -> list[str]:
    return sorted(_REGISTRY.keys())


@register_task("echo")
async def echo_task(payload: dict) -> dict:
    return {"echoed": payload}


@register_task("sleep")
async def sleep_task(payload: dict) -> dict:
    duration = float(payload.get("seconds", 1))
    duration = min(duration, 300)  # safety cap
    await asyncio.sleep(duration)
    return {"slept_seconds": duration}


@register_task("http_request")
async def http_request_task(payload: dict) -> dict:
    url = payload["url"]
    method = payload.get("method", "GET").upper()
    timeout = float(payload.get("timeout", 10))
    async with httpx.AsyncClient(timeout=timeout) as client:
        response = await client.request(method, url, json=payload.get("body"))
    return {"status_code": response.status_code, "response_size": len(response.content)}


@register_task("send_email")
async def send_email_task(payload: dict) -> dict:
    # Simulated email send -- no real network I/O. Useful for demos/tests.
    to = payload.get("to")
    subject = payload.get("subject", "")
    await asyncio.sleep(0.05)
    return {"status": "sent", "to": to, "subject": subject}


@register_task("data_processing")
async def data_processing_task(payload: dict) -> dict:
    # Simulated CPU-light data processing step.
    records = payload.get("records", [])
    await asyncio.sleep(0.05 + 0.001 * len(records))
    return {"processed_count": len(records)}


@register_task("flaky")
async def flaky_task(payload: dict) -> dict:
    """Fails a configurable percentage of the time. Useful for testing retries/DLQ."""
    failure_rate = float(payload.get("failure_rate", 0.5))
    if random.random() < failure_rate:
        raise RuntimeError("Simulated flaky task failure")
    return {"status": "ok"}
