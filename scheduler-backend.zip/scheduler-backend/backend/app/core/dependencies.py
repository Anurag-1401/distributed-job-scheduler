import uuid

from fastapi import Depends, Header
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.exceptions import UnauthorizedError
from app.core.security import decode_access_token
from app.db.session import get_db
from app.models.user import User
from app.repositories.user_repo import UserRepository


async def get_current_user(
    authorization: str | None = Header(default=None),
    db: AsyncSession = Depends(get_db),
) -> User:
    if not authorization or not authorization.lower().startswith("bearer "):
        raise UnauthorizedError("Missing or invalid Authorization header", code="MISSING_TOKEN")

    token = authorization.split(" ", 1)[1]
    try:
        payload = decode_access_token(token)
    except ValueError as exc:
        raise UnauthorizedError("Invalid or expired token", code="INVALID_TOKEN") from exc

    user_id = payload.get("sub")
    if not user_id:
        raise UnauthorizedError("Invalid token payload", code="INVALID_TOKEN")

    users = UserRepository(db)
    user = await users.get(uuid.UUID(user_id))
    if user is None or not user.is_active:
        raise UnauthorizedError("User not found or inactive", code="INVALID_TOKEN")
    return user
