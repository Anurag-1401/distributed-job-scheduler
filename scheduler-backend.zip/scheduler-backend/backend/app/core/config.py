"""
Application configuration.

All configuration is sourced from environment variables (with sane local
defaults) so that secrets are never committed to source control. See
`.env.example` at the repository root for the full list of variables.
"""
from functools import lru_cache
from typing import List

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    # --- General -----------------------------------------------------
    APP_NAME: str = "Distributed Job Scheduler"
    ENVIRONMENT: str = "development"
    DEBUG: bool = True

    # --- Database ------------------------------------------------------
    # Async URL used by the application (asyncpg driver).
    DATABASE_URL: str = "postgresql+asyncpg://scheduler:scheduler@localhost:5432/scheduler"
    # Sync URL used by Alembic migrations (psycopg2 driver).
    DATABASE_URL_SYNC: str = "postgresql+psycopg2://scheduler:scheduler@localhost:5432/scheduler"
    DB_POOL_SIZE: int = 10
    DB_MAX_OVERFLOW: int = 20

    # --- Redis -----------------------------------------------------------
    REDIS_URL: str = "redis://localhost:6379/0"

    # --- Auth / JWT ------------------------------------------------------
    JWT_SECRET_KEY: str = "CHANGE_ME_IN_PRODUCTION"
    JWT_ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60 * 24

    # --- CORS --------------------------------------------------------------
    CORS_ORIGINS: List[str] = ["http://localhost:5173", "http://localhost:3000"]

    # --- Worker defaults -----------------------------------------------
    WORKER_POLL_INTERVAL_SECONDS: float = 1.0
    WORKER_HEARTBEAT_INTERVAL_SECONDS: float = 5.0
    WORKER_HEARTBEAT_TIMEOUT_SECONDS: float = 20.0
    WORKER_DEFAULT_CONCURRENCY: int = 5
    WORKER_GRACEFUL_SHUTDOWN_TIMEOUT_SECONDS: float = 30.0

    # --- Scheduler defaults ---------------------------------------------
    SCHEDULER_POLL_INTERVAL_SECONDS: float = 1.0
    SCHEDULER_LOCK_KEY: int = 727272  # advisory lock key (arbitrary constant)

    # --- Recovery / reaper -------------------------------------------------
    RECOVERY_POLL_INTERVAL_SECONDS: float = 10.0
    JOB_LEASE_SECONDS: float = 60.0

    # --- Rate limiting -------------------------------------------------
    RATE_LIMIT_PER_MINUTE: int = 120


@lru_cache
def get_settings() -> Settings:
    return Settings()


settings = get_settings()
