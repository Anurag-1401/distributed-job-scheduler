import time
from collections import defaultdict, deque

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import ValidationError as PydanticValidationError
from starlette.exceptions import HTTPException as StarletteHTTPException

from app.api.v1.router import api_router
from app.core.config import settings
from app.core.exceptions import AppError, RateLimitedError
from app.core.logging import configure_logging

configure_logging(debug=settings.DEBUG)

app = FastAPI(
    title=settings.APP_NAME,
    description="Production-inspired distributed background job scheduling platform.",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# --- Minimal in-memory sliding-window rate limiter (per client IP) --------
# NOTE: this is a lightweight, single-process limiter suitable for a demo /
# small deployment. A production multi-instance deployment should back this
# with Redis (e.g. a token-bucket implemented with INCR + EXPIRE) so limits
# are enforced consistently across all API replicas.
_request_log: dict[str, deque] = defaultdict(deque)


@app.middleware("http")
async def rate_limit_middleware(request: Request, call_next):
    if request.url.path in ("/health", "/ready", "/docs", "/redoc", "/openapi.json"):
        return await call_next(request)

    client_ip = request.client.host if request.client else "unknown"
    now = time.monotonic()
    window = _request_log[client_ip]
    while window and now - window[0] > 60:
        window.popleft()

    if len(window) >= settings.RATE_LIMIT_PER_MINUTE:
        err = RateLimitedError("Too many requests, please slow down", code="RATE_LIMITED")
        return JSONResponse(status_code=err.status_code, content=err.to_dict())

    window.append(now)
    return await call_next(request)


# --- Structured error handlers -------------------------------------------
@app.exception_handler(AppError)
async def app_error_handler(request: Request, exc: AppError):
    return JSONResponse(status_code=exc.status_code, content=exc.to_dict())


@app.exception_handler(StarletteHTTPException)
async def http_exception_handler(request: Request, exc: StarletteHTTPException):
    return JSONResponse(
        status_code=exc.status_code,
        content={"error": {"code": "HTTP_ERROR", "message": str(exc.detail), "details": {}}},
    )


@app.exception_handler(PydanticValidationError)
async def validation_exception_handler(request: Request, exc: PydanticValidationError):
    return JSONResponse(
        status_code=422,
        content={"error": {"code": "VALIDATION_ERROR", "message": "Request validation failed", "details": {"errors": exc.errors()}}},
    )


app.include_router(api_router)
