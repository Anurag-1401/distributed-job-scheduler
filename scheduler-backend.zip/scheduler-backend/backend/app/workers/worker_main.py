"""
Standalone worker process entrypoint.

Usage:
    python -m app.workers.worker_main

Environment variables (see app.core.config.Settings):
    WORKER_DEFAULT_CONCURRENCY, WORKER_POLL_INTERVAL_SECONDS,
    WORKER_HEARTBEAT_INTERVAL_SECONDS, JOB_LEASE_SECONDS,
    WORKER_GRACEFUL_SHUTDOWN_TIMEOUT_SECONDS

A unique worker_key is generated per process (hostname + PID + short uuid)
unless WORKER_KEY is explicitly set, allowing `docker compose up --scale
worker=3` to run multiple independent worker identities.
"""
import asyncio
import os
import socket
import uuid

from app.core.logging import configure_logging
from app.core.config import settings
from app.workers.engine import WorkerEngine


def _default_worker_key() -> str:
    return f"{socket.gethostname()}-{os.getpid()}-{uuid.uuid4().hex[:8]}"


async def main() -> None:
    configure_logging(debug=settings.DEBUG)
    worker_key = os.environ.get("WORKER_KEY", _default_worker_key())
    engine = WorkerEngine(worker_key=worker_key)
    await engine.run()


if __name__ == "__main__":
    asyncio.run(main())
