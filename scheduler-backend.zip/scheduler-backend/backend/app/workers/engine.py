"""
Worker engine.

A worker process:
  1. registers itself with a unique worker_key
  2. sends periodic heartbeats
  3. polls eligible queues and atomically claims jobs (FOR UPDATE SKIP LOCKED)
  4. executes claimed jobs concurrently, bounded by each queue's
     concurrency_limit and the worker's own max_concurrency
  5. records execution attempts, logs, and final job status
  6. handles retries (via the retry engine) and DLQ transitions
  7. shuts down gracefully: stops claiming new work, waits for in-flight
     jobs (up to a timeout), then exits

Delivery semantics: this system provides AT-LEAST-ONCE execution. A job may
be executed more than once if a worker crashes after completing the task's
side effects but before persisting the COMPLETED status (see docs/worker-design.md).
Task authors should design idempotent tasks where duplicate execution matters.
"""
import asyncio
import signal
import time
import uuid
from datetime import datetime, timezone

import structlog

from app.core.config import settings
from app.db.session import session_scope
from app.models.enums import ExecutionStatus, JobStatus, RetryBackoffStrategy, WorkerStatus
from app.models.job import Job
from app.models.job_execution import JobExecution
from app.models.job_log import JobLog
from app.models.queue import Queue
from app.repositories.execution_repo import JobExecutionRepository, JobLogRepository
from app.repositories.job_repo import JobRepository
from app.repositories.queue_repo import QueueRepository, RetryPolicyRepository
from app.repositories.worker_repo import WorkerRepository
from app.services.dlq_service import move_job_to_dead_letter
from app.services.job_service import transition_job_status
from app.services.retry_service import compute_backoff_seconds
from app.tasks.registry import get_task_handler

logger = structlog.get_logger()


class WorkerEngine:
    def __init__(
        self,
        worker_key: str,
        *,
        max_concurrency: int = settings.WORKER_DEFAULT_CONCURRENCY,
        poll_interval: float = settings.WORKER_POLL_INTERVAL_SECONDS,
        heartbeat_interval: float = settings.WORKER_HEARTBEAT_INTERVAL_SECONDS,
        lease_seconds: float = settings.JOB_LEASE_SECONDS,
        shutdown_timeout: float = settings.WORKER_GRACEFUL_SHUTDOWN_TIMEOUT_SECONDS,
    ):
        self.worker_key = worker_key
        self.max_concurrency = max_concurrency
        self.poll_interval = poll_interval
        self.heartbeat_interval = heartbeat_interval
        self.lease_seconds = lease_seconds
        self.shutdown_timeout = shutdown_timeout

        self.worker_id: uuid.UUID | None = None
        self._stopping = asyncio.Event()
        self._semaphore = asyncio.Semaphore(max_concurrency)
        self._active_tasks: set[asyncio.Task] = set()
        self._active_count = 0

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------
    async def register(self) -> None:
        async with session_scope() as session:
            repo = WorkerRepository(session)
            existing = await repo.get_by_key(self.worker_key)
            now = datetime.now(timezone.utc)
            if existing:
                existing.status = WorkerStatus.ONLINE
                existing.registered_at = now
                self.worker_id = existing.id
            else:
                from app.models.worker import Worker
                worker = Worker(worker_key=self.worker_key, status=WorkerStatus.ONLINE, registered_at=now)
                worker = await repo.add(worker)
                self.worker_id = worker.id
        logger.info("worker_registered", worker_id=str(self.worker_id), worker_key=self.worker_key)

    async def run(self) -> None:
        await self.register()

        loop = asyncio.get_event_loop()
        for sig in (signal.SIGINT, signal.SIGTERM):
            try:
                loop.add_signal_handler(sig, self._stopping.set)
            except NotImplementedError:
                pass  # Windows

        heartbeat_task = asyncio.create_task(self._heartbeat_loop())
        poll_task = asyncio.create_task(self._poll_loop())

        await self._stopping.wait()
        logger.info("worker_shutdown_initiated", worker_id=str(self.worker_id))

        poll_task.cancel()
        heartbeat_task.cancel()

        # Wait for in-flight executions to finish, bounded by timeout.
        deadline = time.monotonic() + self.shutdown_timeout
        while self._active_tasks and time.monotonic() < deadline:
            await asyncio.sleep(0.2)

        for t in list(self._active_tasks):
            t.cancel()

        async with session_scope() as session:
            repo = WorkerRepository(session)
            worker = await repo.get(self.worker_id)
            if worker:
                worker.status = WorkerStatus.OFFLINE
        logger.info("worker_shutdown_complete", worker_id=str(self.worker_id))

    def stop(self) -> None:
        self._stopping.set()

    # ------------------------------------------------------------------
    # Heartbeat
    # ------------------------------------------------------------------
    async def _heartbeat_loop(self) -> None:
        while True:
            try:
                async with session_scope() as session:
                    repo = WorkerRepository(session)
                    from app.repositories.worker_repo import WorkerHeartbeatRepository
                    from app.models.worker_heartbeat import WorkerHeartbeat

                    worker = await repo.get(self.worker_id)
                    now = datetime.now(timezone.utc)
                    if worker:
                        worker.last_heartbeat_at = now
                        worker.status = WorkerStatus.ONLINE
                    hb_repo = WorkerHeartbeatRepository(session)
                    await hb_repo.add(
                        WorkerHeartbeat(
                            worker_id=self.worker_id,
                            heartbeat_at=now,
                            status=WorkerStatus.ONLINE.value,
                            current_job_count=self._active_count,
                        )
                    )
            except Exception:
                logger.exception("heartbeat_failed", worker_id=str(self.worker_id))
            await asyncio.sleep(self.heartbeat_interval)

    # ------------------------------------------------------------------
    # Polling / claiming
    # ------------------------------------------------------------------
    async def _poll_loop(self) -> None:
        while True:
            try:
                if self._semaphore.locked():
                    await asyncio.sleep(self.poll_interval)
                    continue
                claimed = await self._try_claim_and_dispatch()
                if not claimed:
                    await asyncio.sleep(self.poll_interval)
            except asyncio.CancelledError:
                raise
            except Exception:
                logger.exception("poll_loop_error", worker_id=str(self.worker_id))
                await asyncio.sleep(self.poll_interval)

    async def _try_claim_and_dispatch(self) -> bool:
        async with session_scope() as session:
            queue_repo = QueueRepository(session)
            job_repo = JobRepository(session)

            # Iterate active queues ordered by priority (highest first),
            # respecting each queue's own concurrency_limit.
            result = await session.execute(
                Queue.__table__.select().where(Queue.status == "ACTIVE").order_by(Queue.priority.desc())
            )
            queue_rows = result.fetchall()

            for row in queue_rows:
                queue_id = row.id
                concurrency_limit = row.concurrency_limit
                running = await job_repo.count_running_for_queue(queue_id)
                if running >= concurrency_limit:
                    continue

                job = await job_repo.claim_next_job(
                    queue_id=queue_id, worker_id=self.worker_id, lease_seconds=self.lease_seconds
                )
                if job is not None:
                    job_id = job.id
                    await session.commit()
                    self._dispatch(job_id)
                    return True
        return False

    def _dispatch(self, job_id: uuid.UUID) -> None:
        task = asyncio.create_task(self._execute_with_semaphore(job_id))
        self._active_tasks.add(task)
        task.add_done_callback(lambda t: self._active_tasks.discard(t))

    async def _execute_with_semaphore(self, job_id: uuid.UUID) -> None:
        async with self._semaphore:
            self._active_count += 1
            try:
                await self._execute_job(job_id)
            except Exception:
                logger.exception("job_execution_unhandled_error", job_id=str(job_id))
            finally:
                self._active_count -= 1

    # ------------------------------------------------------------------
    # Execution
    # ------------------------------------------------------------------
    async def _execute_job(self, job_id: uuid.UUID) -> None:
        log = logger.bind(job_id=str(job_id), worker_id=str(self.worker_id))

        async with session_scope() as session:
            job_repo = JobRepository(session)
            exec_repo = JobExecutionRepository(session)
            log_repo = JobLogRepository(session)

            job = await job_repo.get(job_id)
            if job is None or job.status != JobStatus.CLAIMED:
                return  # already handled (e.g. recovered by reaper)

            transition_job_status(job, JobStatus.RUNNING)
            job.started_at = datetime.now(timezone.utc)
            job.attempt_count += 1

            attempt_number = await exec_repo.next_attempt_number(job_id)
            execution = JobExecution(
                job_id=job_id,
                worker_id=self.worker_id,
                attempt_number=attempt_number,
                status=ExecutionStatus.RUNNING,
                started_at=job.started_at,
            )
            execution = await exec_repo.add(execution)
            await log_repo.add(JobLog(
                job_id=job_id, execution_id=execution.id, timestamp=datetime.now(timezone.utc),
                level="INFO", message=f"Attempt {attempt_number} started for task '{job.task_name}'",
            ))
            task_name, payload, max_attempts = job.task_name, job.payload, job.max_attempts
            queue_id = job.queue_id
            execution_id = execution.id

        # Execute the task OUTSIDE the DB transaction so a slow/hanging task
        # never holds a database connection or row lock.
        start = time.monotonic()
        error_message: str | None = None
        result: dict | None = None
        succeeded = False
        try:
            handler = get_task_handler(task_name)
            result = await handler(payload)
            succeeded = True
        except KeyError as exc:
            error_message = f"Unknown task type: {exc}"
        except Exception as exc:  # noqa: BLE001 - we must capture any task failure
            error_message = f"{type(exc).__name__}: {exc}"
        duration_ms = (time.monotonic() - start) * 1000

        async with session_scope() as session:
            job_repo = JobRepository(session)
            exec_repo = JobExecutionRepository(session)
            log_repo = JobLogRepository(session)
            queue_repo = QueueRepository(session)
            retry_repo = RetryPolicyRepository(session)

            job = await job_repo.get(job_id)
            execution = await exec_repo.get(execution_id)
            now = datetime.now(timezone.utc)

            execution.completed_at = now
            execution.duration_ms = duration_ms
            if succeeded:
                execution.status = ExecutionStatus.SUCCEEDED
                execution.result = result
                transition_job_status(job, JobStatus.COMPLETED)
                job.completed_at = now
                await log_repo.add(JobLog(
                    job_id=job_id, execution_id=execution.id, timestamp=now,
                    level="INFO", message="Job completed successfully",
                ))
            else:
                execution.status = ExecutionStatus.FAILED
                execution.error = error_message
                await log_repo.add(JobLog(
                    job_id=job_id, execution_id=execution.id, timestamp=now,
                    level="ERROR", message=f"Attempt failed: {error_message}",
                ))
                transition_job_status(job, JobStatus.FAILED)

                if job.attempt_count >= max_attempts:
                    transition_job_status(job, JobStatus.DEAD_LETTER)
                    await move_job_to_dead_letter(
                        session, job, reason="Retry attempts exhausted", final_error=error_message
                    )
                    await log_repo.add(JobLog(
                        job_id=job_id, execution_id=execution.id, timestamp=now,
                        level="ERROR", message="Job moved to dead letter queue after exhausting retries",
                    ))
                else:
                    queue = await queue_repo.get(queue_id)
                    policy = await retry_repo.get(queue.retry_policy_id) if queue and queue.retry_policy_id else None
                    strategy = policy.strategy if policy else RetryBackoffStrategy.EXPONENTIAL
                    base_delay = policy.base_delay_seconds if policy else 2.0
                    max_delay = policy.max_delay_seconds if policy else 300.0
                    jitter = policy.jitter if policy else True

                    delay = compute_backoff_seconds(
                        strategy=strategy, attempt_number=job.attempt_count,
                        base_delay_seconds=base_delay, max_delay_seconds=max_delay, jitter=jitter,
                    )
                    transition_job_status(job, JobStatus.RETRYING)
                    transition_job_status(job, JobStatus.QUEUED)
                    from datetime import timedelta
                    job.scheduled_at = now + timedelta(seconds=delay)
                    job.worker_id = None
                    job.claimed_at = None
                    job.lease_expires_at = None
                    await log_repo.add(JobLog(
                        job_id=job_id, execution_id=execution.id, timestamp=now,
                        level="WARNING", message=f"Retry {job.attempt_count}/{max_attempts} scheduled in {delay:.1f}s",
                    ))

        log.info("job_execution_finished", succeeded=succeeded, duration_ms=duration_ms)
