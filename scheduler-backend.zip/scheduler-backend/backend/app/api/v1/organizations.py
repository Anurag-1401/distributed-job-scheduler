import uuid

from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.dependencies import get_current_user
from app.db.session import get_db
from app.models.user import User
from app.schemas.organization import OrganizationCreate, OrganizationMemberInvite, OrganizationMemberOut, OrganizationOut
from app.services.organization_service import OrganizationService, ADMIN_ROLES

router = APIRouter(prefix="/api/v1/organizations", tags=["organizations"])


@router.post("", response_model=OrganizationOut, status_code=201)
async def create_organization(data: OrganizationCreate, db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)):
    service = OrganizationService(db)
    return await service.create_organization(user.id, data)


@router.get("", response_model=list[OrganizationOut])
async def list_organizations(db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)):
    service = OrganizationService(db)
    return await service.list_organizations(user.id)


@router.get("/{organization_id}", response_model=OrganizationOut)
async def get_organization(organization_id: uuid.UUID, db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)):
    service = OrganizationService(db)
    await service.require_membership(organization_id, user.id)
    return await service.get_organization(organization_id)


@router.post("/{organization_id}/members", response_model=OrganizationMemberOut, status_code=201)
async def add_member(
    organization_id: uuid.UUID,
    data: OrganizationMemberInvite,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    service = OrganizationService(db)
    await service.require_role(organization_id, user.id, ADMIN_ROLES)
    return await service.add_member(organization_id, data.user_id, data.role)
