import uuid
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.dependencies import get_current_user
from app.core.exceptions import NotFoundError
from app.db.session import get_db
from app.models.enums import JobStatus
from app.models.scheduled_job import ScheduledJob
from app.models.user import User
from app.repositories.scheduled_job_repo import ScheduledJobRepository
from app.schemas.job import (
    BatchJobCreate, BatchProgress, JobCreate, JobOut, ScheduledJobCreate, ScheduledJobOut, ScheduledJobUpdate,
)
from app.schemas.common import Page
from app.scheduler.engine import compute_next_run
from app.services.job_service import JobService
from app.services.queue_service import QueueService
from app.utils.pagination import paginate

router = APIRouter(prefix="/api/v1", tags=["jobs"])


@router.post("/jobs", response_model=JobOut, status_code=201)
async def create_job(data: JobCreate, db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)):
    service = JobService(db)
    return await service.create_job(user.id, data)


@router.post("/jobs/batch", response_model=list[JobOut], status_code=201)
async def create_batch(data: BatchJobCreate, db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)):
    service = JobService(db)
    return await service.create_batch(user.id, data)


@router.get("/jobs", response_model=Page[JobOut])
async def list_jobs(
    queue_id: uuid.UUID | None = None,
    status: JobStatus | None = None,
    worker_id: uuid.UUID | None = None,
    priority: int | None = None,
    created_after: datetime | None = None,
    page: int = Query(default=1, ge=1),
    limit: int = Query(default=20, ge=1, le=200),
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    service = JobService(db)
    items, total = await service.list_jobs(
        user.id, queue_id=queue_id, status=status, worker_id=worker_id, priority=priority,
        created_after=created_after, limit=limit, offset=(page - 1) * limit,
    )
    return paginate(items, total, page, limit)


@router.get("/jobs/{job_id}", response_model=JobOut)
async def get_job(job_id: uuid.UUID, db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)):
    service = JobService(db)
    return await service.get_job_for_user(job_id, user.id)


@router.post("/jobs/{job_id}/cancel", response_model=JobOut)
async def cancel_job(job_id: uuid.UUID, db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)):
    service = JobService(db)
    return await service.cancel_job(job_id, user.id)


@router.get("/jobs/{job_id}/batch-progress", response_model=BatchProgress)
async def batch_progress(job_id: uuid.UUID, db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)):
    service = JobService(db)
    return await service.get_batch_progress(job_id, user.id)


# ----------------------------------------------------------------------
# Recurring / cron scheduled jobs
# ----------------------------------------------------------------------

@router.post("/scheduled-jobs", response_model=ScheduledJobOut, status_code=201)
async def create_scheduled_job(data: ScheduledJobCreate, db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)):
    queue_service = QueueService(db)
    queue = await queue_service.get_queue_for_user(data.queue_id, user.id)

    next_run_at = compute_next_run(data.cron_expression, datetime.now(timezone.utc))
    sj = ScheduledJob(
        queue_id=queue.id,
        task_name=data.task_name,
        payload=data.payload,
        cron_expression=data.cron_expression,
        timezone=data.timezone,
        priority=data.priority,
        max_attempts=data.max_attempts,
        next_run_at=next_run_at,
        enabled=data.enabled,
    )
    repo = ScheduledJobRepository(db)
    sj = await repo.add(sj)
    await db.commit()
    return sj


@router.get("/scheduled-jobs", response_model=list[ScheduledJobOut])
async def list_scheduled_jobs(db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)):
    repo = ScheduledJobRepository(db)
    return await repo.list_all()


@router.patch("/scheduled-jobs/{scheduled_job_id}", response_model=ScheduledJobOut)
async def update_scheduled_job(
    scheduled_job_id: uuid.UUID, data: ScheduledJobUpdate, db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)
):
    repo = ScheduledJobRepository(db)
    sj = await repo.get(scheduled_job_id)
    if sj is None:
        raise NotFoundError("Scheduled job not found", code="SCHEDULED_JOB_NOT_FOUND")
    if data.cron_expression is not None:
        sj.cron_expression = data.cron_expression
        sj.next_run_at = compute_next_run(data.cron_expression, datetime.now(timezone.utc))
    if data.enabled is not None:
        sj.enabled = data.enabled
    if data.payload is not None:
        sj.payload = data.payload
    if data.priority is not None:
        sj.priority = data.priority
    await db.commit()
    return sj
