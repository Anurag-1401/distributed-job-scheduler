import uuid

from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.dependencies import get_current_user
from app.db.session import get_db
from app.models.user import User
from app.repositories.execution_repo import JobExecutionRepository, JobLogRepository
from app.schemas.execution import JobExecutionOut, JobLogOut
from app.services.job_service import JobService

router = APIRouter(prefix="/api/v1", tags=["executions"])


@router.get("/jobs/{job_id}/executions", response_model=list[JobExecutionOut])
async def list_executions(job_id: uuid.UUID, db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)):
    job_service = JobService(db)
    await job_service.get_job_for_user(job_id, user.id)  # authorization / existence check
    repo = JobExecutionRepository(db)
    return await repo.list_for_job(job_id)


@router.get("/jobs/{job_id}/logs", response_model=list[JobLogOut])
async def list_job_logs(job_id: uuid.UUID, db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)):
    job_service = JobService(db)
    await job_service.get_job_for_user(job_id, user.id)
    repo = JobLogRepository(db)
    return await repo.list_for_job(job_id)


@router.get("/executions/{execution_id}/logs", response_model=list[JobLogOut])
async def list_execution_logs(execution_id: uuid.UUID, db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)):
    exec_repo = JobExecutionRepository(db)
    execution = await exec_repo.get(execution_id)
    if execution is None:
        from app.core.exceptions import NotFoundError
        raise NotFoundError("Execution not found", code="EXECUTION_NOT_FOUND")
    job_service = JobService(db)
    await job_service.get_job_for_user(execution.job_id, user.id)
    log_repo = JobLogRepository(db)
    return await log_repo.list_for_job(execution.job_id, execution_id=execution_id)
