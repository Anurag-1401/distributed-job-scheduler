import uuid

from fastapi import APIRouter, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.dependencies import get_current_user
from app.db.session import get_db
from app.models.user import User
from app.schemas.common import Page
from app.schemas.dlq import DeadLetterJobOut, DLQRetryResponse
from app.services.job_service import JobService
from app.utils.pagination import paginate

router = APIRouter(prefix="/api/v1/dlq", tags=["dlq"])


@router.get("", response_model=Page[DeadLetterJobOut])
async def list_dlq(
    archived: bool | None = None,
    page: int = Query(default=1, ge=1),
    limit: int = Query(default=20, ge=1, le=200),
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    service = JobService(db)
    items, total = await service.list_dlq(user.id, archived=archived, limit=limit, offset=(page - 1) * limit)
    return paginate(items, total, page, limit)


@router.get("/{dlq_id}", response_model=DeadLetterJobOut)
async def get_dlq_entry(dlq_id: uuid.UUID, db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)):
    service = JobService(db)
    entry = await service.dlq.get(dlq_id)
    if entry is None:
        from app.core.exceptions import NotFoundError
        raise NotFoundError("Dead letter entry not found", code="DLQ_NOT_FOUND")
    await service.get_job_for_user(entry.job_id, user.id)
    return entry


@router.post("/{dlq_id}/retry", response_model=DLQRetryResponse)
async def retry_dlq(dlq_id: uuid.UUID, db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)):
    service = JobService(db)
    job = await service.retry_dead_letter_job(dlq_id, user.id)
    return DLQRetryResponse(job_id=job.id)


@router.delete("/{dlq_id}", status_code=204)
async def archive_dlq(dlq_id: uuid.UUID, db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)):
    service = JobService(db)
    await service.archive_dlq(dlq_id, user.id)
