import uuid

from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.dependencies import get_current_user
from app.db.session import get_db
from app.models.user import User
from app.schemas.worker import WorkerHeartbeatIn, WorkerOut, WorkerRegister
from app.services.worker_service import WorkerService

router = APIRouter(prefix="/api/v1/workers", tags=["workers"])


@router.post("/register", response_model=WorkerOut, status_code=201)
async def register_worker(data: WorkerRegister, db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)):
    service = WorkerService(db)
    return await service.register(data)


@router.post("/{worker_id}/heartbeat", response_model=WorkerOut)
async def heartbeat(
    worker_id: uuid.UUID, data: WorkerHeartbeatIn, db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)
):
    service = WorkerService(db)
    return await service.record_heartbeat(worker_id, data)


@router.get("", response_model=list[WorkerOut])
async def list_workers(db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)):
    service = WorkerService(db)
    return await service.list_workers()


@router.get("/{worker_id}", response_model=WorkerOut)
async def get_worker(worker_id: uuid.UUID, db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)):
    service = WorkerService(db)
    return await service.get_worker(worker_id)
