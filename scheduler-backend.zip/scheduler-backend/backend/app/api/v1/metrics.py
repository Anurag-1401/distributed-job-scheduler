from fastapi import APIRouter, Depends
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.dependencies import get_current_user
from app.db.session import get_db
from app.models.user import User
from app.services.metrics_service import MetricsService

router = APIRouter(prefix="/api/v1/metrics", tags=["metrics"])


@router.get("/overview")
async def metrics_overview(db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)):
    service = MetricsService(db)
    return await service.overview()
