import uuid

from fastapi import APIRouter, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.dependencies import get_current_user
from app.db.session import get_db
from app.models.enums import QueueStatus
from app.models.user import User
from app.schemas.queue import QueueCreate, QueueOut, QueueStats, QueueUpdate, RetryPolicyCreate, RetryPolicyOut
from app.services.queue_service import QueueService
from app.repositories.queue_repo import RetryPolicyRepository
from app.models.retry_policy import RetryPolicy

router = APIRouter(prefix="/api/v1", tags=["queues"])


@router.post("/retry-policies", response_model=RetryPolicyOut, status_code=201)
async def create_retry_policy(data: RetryPolicyCreate, db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)):
    repo = RetryPolicyRepository(db)
    policy = RetryPolicy(**data.model_dump())
    policy = await repo.add(policy)
    await db.commit()
    return policy


@router.post("/queues", response_model=QueueOut, status_code=201)
async def create_queue(data: QueueCreate, db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)):
    service = QueueService(db)
    return await service.create_queue(user.id, data)


@router.get("/projects/{project_id}/queues", response_model=list[QueueOut])
async def list_queues(project_id: uuid.UUID, db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)):
    service = QueueService(db)
    return await service.list_queues(project_id, user.id)


@router.get("/queues/{queue_id}", response_model=QueueOut)
async def get_queue(queue_id: uuid.UUID, db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)):
    service = QueueService(db)
    return await service.get_queue_for_user(queue_id, user.id)


@router.patch("/queues/{queue_id}", response_model=QueueOut)
async def update_queue(
    queue_id: uuid.UUID, data: QueueUpdate, db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)
):
    service = QueueService(db)
    return await service.update_queue(queue_id, user.id, data)


@router.post("/queues/{queue_id}/pause", response_model=QueueOut)
async def pause_queue(queue_id: uuid.UUID, db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)):
    service = QueueService(db)
    return await service.set_status(queue_id, user.id, QueueStatus.PAUSED)


@router.post("/queues/{queue_id}/resume", response_model=QueueOut)
async def resume_queue(queue_id: uuid.UUID, db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)):
    service = QueueService(db)
    return await service.set_status(queue_id, user.id, QueueStatus.ACTIVE)


@router.get("/queues/{queue_id}/stats", response_model=QueueStats)
async def queue_stats(queue_id: uuid.UUID, db: AsyncSession = Depends(get_db), user: User = Depends(get_current_user)):
    service = QueueService(db)
    return await service.get_stats(queue_id, user.id)
