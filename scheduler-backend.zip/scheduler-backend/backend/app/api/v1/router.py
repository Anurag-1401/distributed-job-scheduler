from fastapi import APIRouter

from app.api.v1 import auth, organizations, projects, queues, jobs, workers, executions, dlq, metrics, health

api_router = APIRouter()
api_router.include_router(health.router)
api_router.include_router(auth.router)
api_router.include_router(organizations.router)
api_router.include_router(projects.router)
api_router.include_router(queues.router)
api_router.include_router(jobs.router)
api_router.include_router(workers.router)
api_router.include_router(executions.router)
api_router.include_router(dlq.router)
api_router.include_router(metrics.router)
