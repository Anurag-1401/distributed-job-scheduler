import uuid
from datetime import datetime
from pydantic import BaseModel

from app.schemas.common import ORMModel


class DeadLetterJobOut(ORMModel):
    id: uuid.UUID
    job_id: uuid.UUID
    worker_id: uuid.UUID | None
    reason: str
    final_error: str | None
    attempts_made: int
    original_payload: dict
    failed_at: datetime
    archived: bool


class DLQRetryResponse(BaseModel):
    job_id: uuid.UUID
    message: str = "Job re-queued from dead letter queue"
