import uuid
from datetime import datetime
from typing import Any, Optional
from pydantic import BaseModel, Field, model_validator

from app.models.enums import JobType, JobStatus
from app.schemas.common import ORMModel


class JobCreate(BaseModel):
    queue_id: uuid.UUID
    job_type: JobType = JobType.IMMEDIATE
    task_name: str = Field(min_length=1, max_length=255)
    payload: dict[str, Any] = Field(default_factory=dict)
    priority: int = Field(default=0, ge=0, le=100)
    max_attempts: int | None = Field(default=None, ge=1, le=50)

    # DELAYED jobs: run after N seconds
    delay_seconds: float | None = Field(default=None, ge=0)
    # SCHEDULED jobs: run at an explicit UTC datetime
    scheduled_at: datetime | None = None

    idempotency_key: str | None = Field(default=None, max_length=255)

    @model_validator(mode="after")
    def validate_by_type(self):
        if self.job_type == JobType.DELAYED and self.delay_seconds is None:
            raise ValueError("delay_seconds is required for DELAYED jobs")
        if self.job_type == JobType.SCHEDULED and self.scheduled_at is None:
            raise ValueError("scheduled_at is required for SCHEDULED jobs")
        if self.job_type == JobType.RECURRING:
            raise ValueError("Use POST /scheduled-jobs to create RECURRING jobs")
        return self


class BatchJobItem(BaseModel):
    task_name: str = Field(min_length=1, max_length=255)
    payload: dict[str, Any] = Field(default_factory=dict)
    priority: int = Field(default=0, ge=0, le=100)


class BatchJobCreate(BaseModel):
    queue_id: uuid.UUID
    jobs: list[BatchJobItem] = Field(min_length=1, max_length=10000)
    max_attempts: int | None = Field(default=None, ge=1, le=50)


class ScheduledJobCreate(BaseModel):
    queue_id: uuid.UUID
    task_name: str = Field(min_length=1, max_length=255)
    payload: dict[str, Any] = Field(default_factory=dict)
    cron_expression: str = Field(min_length=1, max_length=120)
    timezone: str = "UTC"
    priority: int = Field(default=0, ge=0, le=100)
    max_attempts: int = Field(default=3, ge=1, le=50)
    enabled: bool = True


class ScheduledJobUpdate(BaseModel):
    cron_expression: str | None = None
    enabled: bool | None = None
    payload: dict[str, Any] | None = None
    priority: int | None = None


class ScheduledJobOut(ORMModel):
    id: uuid.UUID
    queue_id: uuid.UUID
    task_name: str
    payload: dict
    cron_expression: str
    timezone: str
    priority: int
    max_attempts: int
    next_run_at: datetime
    last_run_at: datetime | None
    enabled: bool
    created_at: datetime
    updated_at: datetime


class JobOut(ORMModel):
    id: uuid.UUID
    queue_id: uuid.UUID
    batch_id: uuid.UUID | None
    job_type: JobType
    task_name: str
    payload: dict
    priority: int
    status: JobStatus
    idempotency_key: str | None
    scheduled_at: datetime
    claimed_at: datetime | None
    started_at: datetime | None
    completed_at: datetime | None
    max_attempts: int
    attempt_count: int
    worker_id: uuid.UUID | None
    scheduled_job_id: uuid.UUID | None
    created_at: datetime
    updated_at: datetime


class BatchProgress(BaseModel):
    batch_id: uuid.UUID
    total: int
    completed: int
    failed: int
    running: int
    queued: int
    other: int
