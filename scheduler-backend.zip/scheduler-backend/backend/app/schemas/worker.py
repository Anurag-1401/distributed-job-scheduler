import uuid
from datetime import datetime
from pydantic import BaseModel

from app.models.enums import WorkerStatus
from app.schemas.common import ORMModel


class WorkerRegister(BaseModel):
    worker_key: str
    hostname: str | None = None


class WorkerHeartbeatIn(BaseModel):
    status: WorkerStatus = WorkerStatus.ONLINE
    current_job_count: int = 0
    meta: dict | None = None


class WorkerOut(ORMModel):
    id: uuid.UUID
    worker_key: str
    hostname: str | None
    status: WorkerStatus
    registered_at: datetime
    last_heartbeat_at: datetime | None
    is_healthy: bool = True
