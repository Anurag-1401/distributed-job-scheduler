import uuid
from datetime import datetime
from pydantic import BaseModel, Field

from app.models.enums import OrgRole
from app.schemas.common import ORMModel


class OrganizationCreate(BaseModel):
    name: str = Field(min_length=1, max_length=255)


class OrganizationOut(ORMModel):
    id: uuid.UUID
    name: str
    created_at: datetime
    updated_at: datetime


class OrganizationMemberOut(ORMModel):
    id: uuid.UUID
    user_id: uuid.UUID
    role: OrgRole


class OrganizationMemberInvite(BaseModel):
    user_id: uuid.UUID
    role: OrgRole = OrgRole.VIEWER
