import uuid
from datetime import datetime
from pydantic import BaseModel

from app.models.enums import ExecutionStatus, LogLevel
from app.schemas.common import ORMModel


class JobExecutionOut(ORMModel):
    id: uuid.UUID
    job_id: uuid.UUID
    worker_id: uuid.UUID | None
    attempt_number: int
    status: ExecutionStatus
    started_at: datetime
    completed_at: datetime | None
    duration_ms: float | None
    error: str | None
    result: dict | None


class JobLogOut(ORMModel):
    id: uuid.UUID
    job_id: uuid.UUID
    execution_id: uuid.UUID | None
    timestamp: datetime
    level: LogLevel
    message: str
    meta: dict | None
