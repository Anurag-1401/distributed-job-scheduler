import uuid
from datetime import datetime
from pydantic import BaseModel, Field

from app.models.enums import QueueStatus, RetryBackoffStrategy
from app.schemas.common import ORMModel


class RetryPolicyCreate(BaseModel):
    name: str = Field(min_length=1, max_length=255)
    strategy: RetryBackoffStrategy = RetryBackoffStrategy.EXPONENTIAL
    max_attempts: int = Field(default=3, ge=1, le=50)
    base_delay_seconds: float = Field(default=2.0, ge=0)
    max_delay_seconds: float = Field(default=300.0, ge=0)
    jitter: bool = True


class RetryPolicyOut(ORMModel):
    id: uuid.UUID
    name: str
    strategy: RetryBackoffStrategy
    max_attempts: int
    base_delay_seconds: float
    max_delay_seconds: float
    jitter: bool


class QueueCreate(BaseModel):
    project_id: uuid.UUID
    name: str = Field(min_length=1, max_length=255)
    priority: int = Field(default=0, ge=0, le=100)
    concurrency_limit: int = Field(default=5, ge=1, le=1000)
    retry_policy_id: uuid.UUID | None = None


class QueueUpdate(BaseModel):
    name: str | None = Field(default=None, min_length=1, max_length=255)
    priority: int | None = Field(default=None, ge=0, le=100)
    concurrency_limit: int | None = Field(default=None, ge=1, le=1000)
    retry_policy_id: uuid.UUID | None = None


class QueueOut(ORMModel):
    id: uuid.UUID
    project_id: uuid.UUID
    name: str
    priority: int
    concurrency_limit: int
    status: QueueStatus
    retry_policy_id: uuid.UUID | None
    created_at: datetime
    updated_at: datetime


class QueueStats(BaseModel):
    queue_id: uuid.UUID
    queued: int
    scheduled: int
    running: int
    completed: int
    failed: int
    dead_letter: int
    throughput_per_minute: float
    avg_execution_time_ms: float | None
