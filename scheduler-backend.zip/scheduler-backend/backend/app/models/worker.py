from sqlalchemy import String, Enum as SAEnum, DateTime
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.base import Base, UUIDPKMixin, TimestampMixin
from app.models.enums import WorkerStatus


class Worker(UUIDPKMixin, TimestampMixin, Base):
    __tablename__ = "workers"

    worker_key: Mapped[str] = mapped_column(String(255), unique=True, nullable=False, index=True)
    hostname: Mapped[str | None] = mapped_column(String(255), nullable=True)
    status: Mapped[WorkerStatus] = mapped_column(SAEnum(WorkerStatus, name="worker_status"), nullable=False, default=WorkerStatus.ONLINE)
    registered_at: Mapped[object] = mapped_column(DateTime(timezone=True), nullable=False)
    last_heartbeat_at: Mapped[object | None] = mapped_column(DateTime(timezone=True), nullable=True)

    heartbeats = relationship("WorkerHeartbeat", back_populates="worker", cascade="all, delete-orphan")
