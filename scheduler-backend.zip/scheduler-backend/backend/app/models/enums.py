import enum


class OrgRole(str, enum.Enum):
    OWNER = "OWNER"
    ADMIN = "ADMIN"
    DEVELOPER = "DEVELOPER"
    VIEWER = "VIEWER"


class QueueStatus(str, enum.Enum):
    ACTIVE = "ACTIVE"
    PAUSED = "PAUSED"


class JobType(str, enum.Enum):
    IMMEDIATE = "IMMEDIATE"
    DELAYED = "DELAYED"
    SCHEDULED = "SCHEDULED"
    RECURRING = "RECURRING"
    BATCH = "BATCH"


class JobStatus(str, enum.Enum):
    SCHEDULED = "SCHEDULED"
    QUEUED = "QUEUED"
    CLAIMED = "CLAIMED"
    RUNNING = "RUNNING"
    COMPLETED = "COMPLETED"
    FAILED = "FAILED"
    RETRYING = "RETRYING"
    CANCELLED = "CANCELLED"
    DEAD_LETTER = "DEAD_LETTER"


# Allowed state transitions for the job lifecycle state machine.
# Enforced centrally in services/job_service.py::transition_job_status
JOB_STATE_TRANSITIONS: dict[JobStatus, set[JobStatus]] = {
    JobStatus.SCHEDULED: {JobStatus.QUEUED, JobStatus.CANCELLED},
    JobStatus.QUEUED: {JobStatus.CLAIMED, JobStatus.CANCELLED},
    JobStatus.CLAIMED: {JobStatus.RUNNING, JobStatus.QUEUED, JobStatus.CANCELLED},
    JobStatus.RUNNING: {JobStatus.COMPLETED, JobStatus.FAILED, JobStatus.CANCELLED, JobStatus.QUEUED},
    JobStatus.FAILED: {JobStatus.RETRYING, JobStatus.DEAD_LETTER},
    JobStatus.RETRYING: {JobStatus.QUEUED, JobStatus.CANCELLED},
    JobStatus.COMPLETED: set(),
    JobStatus.CANCELLED: set(),
    JobStatus.DEAD_LETTER: {JobStatus.QUEUED},  # manual DLQ retry
}


class RetryBackoffStrategy(str, enum.Enum):
    FIXED = "FIXED"
    LINEAR = "LINEAR"
    EXPONENTIAL = "EXPONENTIAL"


class ExecutionStatus(str, enum.Enum):
    RUNNING = "RUNNING"
    SUCCEEDED = "SUCCEEDED"
    FAILED = "FAILED"


class LogLevel(str, enum.Enum):
    DEBUG = "DEBUG"
    INFO = "INFO"
    WARNING = "WARNING"
    ERROR = "ERROR"


class WorkerStatus(str, enum.Enum):
    ONLINE = "ONLINE"
    OFFLINE = "OFFLINE"
    DRAINING = "DRAINING"
