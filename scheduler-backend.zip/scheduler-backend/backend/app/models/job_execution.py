from sqlalchemy import Integer, ForeignKey, Enum as SAEnum, DateTime, Text, Float, JSON, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.base import Base, UUIDPKMixin, GUID
from app.models.enums import ExecutionStatus


class JobExecution(UUIDPKMixin, Base):
    """
    One row per execution *attempt*. Rows are append-only; historical
    attempts are never overwritten or deleted.
    """
    __tablename__ = "job_executions"
    __table_args__ = (
        UniqueConstraint("job_id", "attempt_number", name="uq_execution_job_attempt"),
    )

    job_id: Mapped[str] = mapped_column(GUID(), ForeignKey("jobs.id", ondelete="CASCADE"), nullable=False, index=True)
    worker_id: Mapped[str | None] = mapped_column(GUID(), ForeignKey("workers.id"), nullable=True, index=True)
    attempt_number: Mapped[int] = mapped_column(Integer, nullable=False)
    status: Mapped[ExecutionStatus] = mapped_column(SAEnum(ExecutionStatus, name="execution_status"), nullable=False, default=ExecutionStatus.RUNNING)

    started_at: Mapped[object] = mapped_column(DateTime(timezone=True), nullable=False)
    completed_at: Mapped[object | None] = mapped_column(DateTime(timezone=True), nullable=True)
    duration_ms: Mapped[float | None] = mapped_column(Float, nullable=True)

    error: Mapped[str | None] = mapped_column(Text, nullable=True)
    result: Mapped[dict | None] = mapped_column(JSON, nullable=True)

    job = relationship("Job", back_populates="executions")
