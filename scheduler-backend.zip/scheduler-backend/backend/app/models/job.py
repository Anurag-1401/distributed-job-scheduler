from sqlalchemy import String, Integer, ForeignKey, Enum as SAEnum, DateTime, JSON, UniqueConstraint, Index
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.base import Base, UUIDPKMixin, TimestampMixin, GUID
from app.models.enums import JobType, JobStatus


class Job(UUIDPKMixin, TimestampMixin, Base):
    __tablename__ = "jobs"
    __table_args__ = (
        # Idempotency: same key cannot create two jobs on the same queue.
        UniqueConstraint("queue_id", "idempotency_key", name="uq_job_queue_idempotency_key"),
        # This composite index backs the atomic-claim query
        # (WHERE queue_id = ? AND status = 'QUEUED' AND scheduled_at <= now()
        #  ORDER BY priority DESC, scheduled_at ASC).
        Index("ix_jobs_claim_lookup", "queue_id", "status", "scheduled_at"),
        Index("ix_jobs_status", "status"),
    )

    queue_id: Mapped[str] = mapped_column(GUID(), ForeignKey("queues.id", ondelete="CASCADE"), nullable=False, index=True)
    batch_id: Mapped[str | None] = mapped_column(GUID(), ForeignKey("jobs.id"), nullable=True, index=True)

    job_type: Mapped[JobType] = mapped_column(SAEnum(JobType, name="job_type"), nullable=False)
    task_name: Mapped[str] = mapped_column(String(255), nullable=False)
    payload: Mapped[dict] = mapped_column(JSON, nullable=False, default=dict)

    priority: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    status: Mapped[JobStatus] = mapped_column(SAEnum(JobStatus, name="job_status"), nullable=False, default=JobStatus.QUEUED)

    idempotency_key: Mapped[str | None] = mapped_column(String(255), nullable=True)

    # Timing
    scheduled_at: Mapped[object] = mapped_column(DateTime(timezone=True), nullable=False, index=True)
    claimed_at: Mapped[object | None] = mapped_column(DateTime(timezone=True), nullable=True)
    started_at: Mapped[object | None] = mapped_column(DateTime(timezone=True), nullable=True)
    completed_at: Mapped[object | None] = mapped_column(DateTime(timezone=True), nullable=True)

    # Retry bookkeeping
    max_attempts: Mapped[int] = mapped_column(Integer, nullable=False, default=3)
    attempt_count: Mapped[int] = mapped_column(Integer, nullable=False, default=0)

    # Claim ownership / lease
    worker_id: Mapped[str | None] = mapped_column(GUID(), ForeignKey("workers.id"), nullable=True, index=True)
    lease_expires_at: Mapped[object | None] = mapped_column(DateTime(timezone=True), nullable=True)

    # Recurring cron linkage
    scheduled_job_id: Mapped[str | None] = mapped_column(GUID(), ForeignKey("scheduled_jobs.id"), nullable=True, index=True)

    queue = relationship("Queue", back_populates="jobs")
    executions = relationship("JobExecution", back_populates="job", cascade="all, delete-orphan", order_by="JobExecution.attempt_number")
    logs = relationship("JobLog", back_populates="job", cascade="all, delete-orphan")
