from sqlalchemy import String, Integer, Float, Enum as SAEnum
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.base import Base, UUIDPKMixin, TimestampMixin
from app.models.enums import RetryBackoffStrategy


class RetryPolicy(UUIDPKMixin, TimestampMixin, Base):
    __tablename__ = "retry_policies"

    name: Mapped[str] = mapped_column(String(255), nullable=False)
    strategy: Mapped[RetryBackoffStrategy] = mapped_column(
        SAEnum(RetryBackoffStrategy, name="retry_backoff_strategy"), nullable=False, default=RetryBackoffStrategy.EXPONENTIAL
    )
    max_attempts: Mapped[int] = mapped_column(Integer, nullable=False, default=3)
    base_delay_seconds: Mapped[float] = mapped_column(Float, nullable=False, default=2.0)
    max_delay_seconds: Mapped[float] = mapped_column(Float, nullable=False, default=300.0)
    jitter: Mapped[bool] = mapped_column(default=True)

    queues = relationship("Queue", back_populates="retry_policy")
