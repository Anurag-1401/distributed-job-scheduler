from sqlalchemy import ForeignKey, Enum as SAEnum, DateTime, Text, JSON
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.base import Base, UUIDPKMixin, GUID
from app.models.enums import LogLevel


class JobLog(UUIDPKMixin, Base):
    __tablename__ = "job_logs"

    job_id: Mapped[str] = mapped_column(GUID(), ForeignKey("jobs.id", ondelete="CASCADE"), nullable=False, index=True)
    execution_id: Mapped[str | None] = mapped_column(GUID(), ForeignKey("job_executions.id", ondelete="CASCADE"), nullable=True, index=True)
    timestamp: Mapped[object] = mapped_column(DateTime(timezone=True), nullable=False)
    level: Mapped[LogLevel] = mapped_column(SAEnum(LogLevel, name="log_level"), nullable=False, default=LogLevel.INFO)
    message: Mapped[str] = mapped_column(Text, nullable=False)
    meta: Mapped[dict | None] = mapped_column(JSON, nullable=True)

    job = relationship("Job", back_populates="logs")
