from sqlalchemy import String, ForeignKey, DateTime, Boolean, JSON, Integer
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.base import Base, UUIDPKMixin, TimestampMixin, GUID


class ScheduledJob(UUIDPKMixin, TimestampMixin, Base):
    """
    Definition of a recurring (cron) job. The scheduler service periodically
    scans enabled rows whose `next_run_at` is due and materializes a
    concrete `Job` row (status=QUEUED) for each firing, then advances
    `next_run_at`. Idempotent generation is enforced via a unique
    constraint on (scheduled_job_id, scheduled fire-time) at the Job level.
    """
    __tablename__ = "scheduled_jobs"

    queue_id: Mapped[str] = mapped_column(GUID(), ForeignKey("queues.id", ondelete="CASCADE"), nullable=False, index=True)
    task_name: Mapped[str] = mapped_column(String(255), nullable=False)
    payload: Mapped[dict] = mapped_column(JSON, nullable=False, default=dict)
    cron_expression: Mapped[str] = mapped_column(String(120), nullable=False)
    timezone: Mapped[str] = mapped_column(String(64), nullable=False, default="UTC")
    priority: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    max_attempts: Mapped[int] = mapped_column(Integer, nullable=False, default=3)

    next_run_at: Mapped[object] = mapped_column(DateTime(timezone=True), nullable=False, index=True)
    last_run_at: Mapped[object | None] = mapped_column(DateTime(timezone=True), nullable=True)
    enabled: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)

    queue = relationship("Queue")
