from sqlalchemy import ForeignKey, DateTime, Text, Integer, JSON, Boolean
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.base import Base, UUIDPKMixin, TimestampMixin, GUID


class DeadLetterJob(UUIDPKMixin, TimestampMixin, Base):
    __tablename__ = "dead_letter_jobs"

    job_id: Mapped[str] = mapped_column(GUID(), ForeignKey("jobs.id", ondelete="CASCADE"), nullable=False, index=True, unique=True)
    worker_id: Mapped[str | None] = mapped_column(GUID(), ForeignKey("workers.id"), nullable=True)
    reason: Mapped[str] = mapped_column(Text, nullable=False)
    final_error: Mapped[str | None] = mapped_column(Text, nullable=True)
    attempts_made: Mapped[int] = mapped_column(Integer, nullable=False)
    original_payload: Mapped[dict] = mapped_column(JSON, nullable=False)
    failed_at: Mapped[object] = mapped_column(DateTime(timezone=True), nullable=False)
    archived: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)

    job = relationship("Job")
