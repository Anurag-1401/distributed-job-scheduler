from sqlalchemy import String, Integer, ForeignKey, Enum as SAEnum, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.base import Base, UUIDPKMixin, TimestampMixin, GUID
from app.models.enums import QueueStatus


class Queue(UUIDPKMixin, TimestampMixin, Base):
    __tablename__ = "queues"
    __table_args__ = (
        UniqueConstraint("project_id", "name", name="uq_queue_project_name"),
    )

    project_id: Mapped[str] = mapped_column(GUID(), ForeignKey("projects.id", ondelete="CASCADE"), nullable=False, index=True)
    retry_policy_id: Mapped[str | None] = mapped_column(GUID(), ForeignKey("retry_policies.id"), nullable=True)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    priority: Mapped[int] = mapped_column(Integer, nullable=False, default=0)  # higher = more urgent
    concurrency_limit: Mapped[int] = mapped_column(Integer, nullable=False, default=5)
    status: Mapped[QueueStatus] = mapped_column(SAEnum(QueueStatus, name="queue_status"), nullable=False, default=QueueStatus.ACTIVE)

    project = relationship("Project", back_populates="queues")
    retry_policy = relationship("RetryPolicy", back_populates="queues")
    jobs = relationship("Job", back_populates="queue", cascade="all, delete-orphan")
