from sqlalchemy import ForeignKey, Integer, String, DateTime, JSON
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.base import Base, UUIDPKMixin, GUID


class WorkerHeartbeat(UUIDPKMixin, Base):
    __tablename__ = "worker_heartbeats"

    worker_id: Mapped[str] = mapped_column(GUID(), ForeignKey("workers.id", ondelete="CASCADE"), nullable=False, index=True)
    heartbeat_at: Mapped[object] = mapped_column(DateTime(timezone=True), nullable=False, index=True)
    status: Mapped[str] = mapped_column(String(50), nullable=False)
    current_job_count: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    meta: Mapped[dict | None] = mapped_column(JSON, nullable=True)

    worker = relationship("Worker", back_populates="heartbeats")
