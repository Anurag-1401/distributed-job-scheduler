import uuid
from sqlalchemy import select

from app.models.dead_letter_job import DeadLetterJob
from app.repositories.base import BaseRepository


class DeadLetterJobRepository(BaseRepository[DeadLetterJob]):
    model = DeadLetterJob

    async def get_by_job_id(self, job_id: uuid.UUID) -> DeadLetterJob | None:
        stmt = select(DeadLetterJob).where(DeadLetterJob.job_id == job_id)
        result = await self.session.execute(stmt)
        return result.scalar_one_or_none()

    async def list_filtered(self, *, archived: bool | None = None, limit: int = 20, offset: int = 0):
        stmt = select(DeadLetterJob)
        if archived is not None:
            stmt = stmt.where(DeadLetterJob.archived == archived)
        total = await self.count(stmt)
        stmt = stmt.order_by(DeadLetterJob.failed_at.desc()).limit(limit).offset(offset)
        result = await self.session.execute(stmt)
        return list(result.scalars().all()), total
