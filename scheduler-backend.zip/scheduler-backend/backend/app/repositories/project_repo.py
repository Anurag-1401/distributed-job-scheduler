import uuid
from sqlalchemy import select

from app.models.project import Project
from app.repositories.base import BaseRepository


class ProjectRepository(BaseRepository[Project]):
    model = Project

    async def list_for_organization(self, organization_id: uuid.UUID) -> list[Project]:
        stmt = select(Project).where(Project.organization_id == organization_id)
        result = await self.session.execute(stmt)
        return list(result.scalars().all())
