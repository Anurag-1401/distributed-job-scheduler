import uuid
from sqlalchemy import select, func

from app.models.job_execution import JobExecution
from app.models.job_log import JobLog
from app.repositories.base import BaseRepository


class JobExecutionRepository(BaseRepository[JobExecution]):
    model = JobExecution

    async def list_for_job(self, job_id: uuid.UUID) -> list[JobExecution]:
        stmt = select(JobExecution).where(JobExecution.job_id == job_id).order_by(JobExecution.attempt_number)
        result = await self.session.execute(stmt)
        return list(result.scalars().all())

    async def next_attempt_number(self, job_id: uuid.UUID) -> int:
        stmt = select(func.coalesce(func.max(JobExecution.attempt_number), 0)).where(JobExecution.job_id == job_id)
        result = await self.session.execute(stmt)
        return result.scalar_one() + 1


class JobLogRepository(BaseRepository[JobLog]):
    model = JobLog

    async def list_for_job(self, job_id: uuid.UUID, *, execution_id: uuid.UUID | None = None) -> list[JobLog]:
        stmt = select(JobLog).where(JobLog.job_id == job_id)
        if execution_id is not None:
            stmt = stmt.where(JobLog.execution_id == execution_id)
        stmt = stmt.order_by(JobLog.timestamp)
        result = await self.session.execute(stmt)
        return list(result.scalars().all())
