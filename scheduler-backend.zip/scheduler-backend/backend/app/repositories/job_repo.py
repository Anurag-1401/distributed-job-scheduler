import uuid
from datetime import datetime, timezone

from sqlalchemy import select, update, and_
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.enums import JobStatus, QueueStatus
from app.models.job import Job
from app.models.queue import Queue
from app.repositories.base import BaseRepository


class JobRepository(BaseRepository[Job]):
    model = Job

    async def get_by_idempotency_key(self, queue_id: uuid.UUID, idempotency_key: str) -> Job | None:
        stmt = select(Job).where(Job.queue_id == queue_id, Job.idempotency_key == idempotency_key)
        result = await self.session.execute(stmt)
        return result.scalar_one_or_none()

    async def list_filtered(
        self,
        *,
        queue_id: uuid.UUID | None = None,
        status: JobStatus | None = None,
        worker_id: uuid.UUID | None = None,
        priority: int | None = None,
        created_after: datetime | None = None,
        batch_id: uuid.UUID | None = None,
        limit: int = 20,
        offset: int = 0,
        order_desc: bool = True,
    ) -> tuple[list[Job], int]:
        stmt = select(Job)
        conditions = []
        if queue_id is not None:
            conditions.append(Job.queue_id == queue_id)
        if status is not None:
            conditions.append(Job.status == status)
        if worker_id is not None:
            conditions.append(Job.worker_id == worker_id)
        if priority is not None:
            conditions.append(Job.priority == priority)
        if created_after is not None:
            conditions.append(Job.created_at >= created_after)
        if batch_id is not None:
            conditions.append(Job.batch_id == batch_id)
        if conditions:
            stmt = stmt.where(and_(*conditions))

        total = await self.count(stmt)

        order_col = Job.created_at.desc() if order_desc else Job.created_at.asc()
        stmt = stmt.order_by(order_col).limit(limit).offset(offset)
        result = await self.session.execute(stmt)
        return list(result.scalars().all()), total

    async def claim_next_job(self, *, queue_id: uuid.UUID, worker_id: uuid.UUID, lease_seconds: float) -> Job | None:
        """
        Atomically claim a single eligible job from a queue.

        Uses `SELECT ... FOR UPDATE SKIP LOCKED` so that concurrently polling
        workers never block on each other and can never claim the same row:
        a row already locked by another worker's in-flight transaction is
        simply skipped rather than waited on.

        Eligibility:
          - queue must be ACTIVE
          - job status must be QUEUED
          - job.scheduled_at <= now()  (respects delayed/scheduled jobs)
          - ordered by priority DESC, scheduled_at ASC (oldest-highest-priority first)
        """
        now = datetime.now(timezone.utc)

        # Confirm queue is active first (cheap, non-locking check).
        queue = await self.session.get(Queue, queue_id)
        if queue is None or queue.status != QueueStatus.ACTIVE:
            return None

        select_stmt = (
            select(Job)
            .where(
                Job.queue_id == queue_id,
                Job.status == JobStatus.QUEUED,
                Job.scheduled_at <= now,
            )
            .order_by(Job.priority.desc(), Job.scheduled_at.asc())
            .limit(1)
            .with_for_update(skip_locked=True)
        )
        result = await self.session.execute(select_stmt)
        job = result.scalar_one_or_none()
        if job is None:
            return None

        from datetime import timedelta

        job.status = JobStatus.CLAIMED
        job.worker_id = worker_id
        job.claimed_at = now
        job.lease_expires_at = now + timedelta(seconds=lease_seconds)

        await self.session.flush()
        return job

    async def find_abandoned_jobs(self, *, limit: int = 100) -> list[Job]:
        """
        Jobs whose claim lease has expired (worker died mid-flight, either
        before or during execution) and are therefore eligible for recovery.
        """
        now = datetime.now(timezone.utc)
        stmt = (
            select(Job)
            .where(
                Job.status.in_([JobStatus.CLAIMED, JobStatus.RUNNING]),
                Job.lease_expires_at.is_not(None),
                Job.lease_expires_at < now,
            )
            .with_for_update(skip_locked=True)
            .limit(limit)
        )
        result = await self.session.execute(stmt)
        return list(result.scalars().all())

    async def count_running_for_queue(self, queue_id: uuid.UUID) -> int:
        stmt = select(Job).where(
            Job.queue_id == queue_id,
            Job.status.in_([JobStatus.CLAIMED, JobStatus.RUNNING]),
        )
        return await self.count(stmt)
