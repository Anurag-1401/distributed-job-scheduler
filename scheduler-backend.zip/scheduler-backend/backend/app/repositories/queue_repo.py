import uuid
from sqlalchemy import select

from app.models.queue import Queue
from app.models.retry_policy import RetryPolicy
from app.repositories.base import BaseRepository


class QueueRepository(BaseRepository[Queue]):
    model = Queue

    async def list_for_project(self, project_id: uuid.UUID) -> list[Queue]:
        stmt = select(Queue).where(Queue.project_id == project_id)
        result = await self.session.execute(stmt)
        return list(result.scalars().all())

    async def get_by_name(self, project_id: uuid.UUID, name: str) -> Queue | None:
        stmt = select(Queue).where(Queue.project_id == project_id, Queue.name == name)
        result = await self.session.execute(stmt)
        return result.scalar_one_or_none()


class RetryPolicyRepository(BaseRepository[RetryPolicy]):
    model = RetryPolicy
