from datetime import datetime, timezone

from sqlalchemy import select

from app.models.scheduled_job import ScheduledJob
from app.repositories.base import BaseRepository


class ScheduledJobRepository(BaseRepository[ScheduledJob]):
    model = ScheduledJob

    async def list_all(self, *, enabled_only: bool = False) -> list[ScheduledJob]:
        stmt = select(ScheduledJob)
        if enabled_only:
            stmt = stmt.where(ScheduledJob.enabled.is_(True))
        result = await self.session.execute(stmt)
        return list(result.scalars().all())

    async def find_due(self, *, limit: int = 100) -> list[ScheduledJob]:
        """
        Lock due rows FOR UPDATE SKIP LOCKED so that if multiple scheduler
        instances run concurrently, each due cron definition is only picked
        up and fired by exactly one of them per tick.
        """
        now = datetime.now(timezone.utc)
        stmt = (
            select(ScheduledJob)
            .where(ScheduledJob.enabled.is_(True), ScheduledJob.next_run_at <= now)
            .with_for_update(skip_locked=True)
            .limit(limit)
        )
        result = await self.session.execute(stmt)
        return list(result.scalars().all())
