import uuid
from datetime import datetime, timedelta, timezone

from sqlalchemy import select

from app.models.worker import Worker
from app.models.worker_heartbeat import WorkerHeartbeat
from app.repositories.base import BaseRepository


class WorkerRepository(BaseRepository[Worker]):
    model = Worker

    async def get_by_key(self, worker_key: str) -> Worker | None:
        stmt = select(Worker).where(Worker.worker_key == worker_key)
        result = await self.session.execute(stmt)
        return result.scalar_one_or_none()

    async def list_all(self) -> list[Worker]:
        result = await self.session.execute(select(Worker))
        return list(result.scalars().all())

    @staticmethod
    def is_healthy(worker: Worker, timeout_seconds: float) -> bool:
        if worker.last_heartbeat_at is None:
            return False
        now = datetime.now(timezone.utc)
        last_heartbeat = worker.last_heartbeat_at
        if last_heartbeat.tzinfo is None:
            # SQLite (used only in the fast test suite) does not reliably
            # round-trip tzinfo on DateTime(timezone=True) columns.
            last_heartbeat = last_heartbeat.replace(tzinfo=timezone.utc)
        return (now - last_heartbeat) <= timedelta(seconds=timeout_seconds)


class WorkerHeartbeatRepository(BaseRepository[WorkerHeartbeat]):
    model = WorkerHeartbeat

    async def list_for_worker(self, worker_id: uuid.UUID, limit: int = 50) -> list[WorkerHeartbeat]:
        stmt = (
            select(WorkerHeartbeat)
            .where(WorkerHeartbeat.worker_id == worker_id)
            .order_by(WorkerHeartbeat.heartbeat_at.desc())
            .limit(limit)
        )
        result = await self.session.execute(stmt)
        return list(result.scalars().all())
