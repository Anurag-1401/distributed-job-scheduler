"""
Standalone scheduler process entrypoint.

Usage:
    python -m app.scheduler.scheduler_main

Only one logical scheduler role is needed, but it is safe to run multiple
replicas: due-row locking (FOR UPDATE SKIP LOCKED) and per-fire idempotency
keys prevent duplicate job generation.
"""
import asyncio
import signal

from app.core.config import settings
from app.core.logging import configure_logging
from app.scheduler.engine import SchedulerEngine


async def main() -> None:
    configure_logging(debug=settings.DEBUG)
    engine = SchedulerEngine()

    loop = asyncio.get_event_loop()
    for sig in (signal.SIGINT, signal.SIGTERM):
        try:
            loop.add_signal_handler(sig, engine.stop)
        except NotImplementedError:
            pass

    await engine.run()


if __name__ == "__main__":
    asyncio.run(main())
