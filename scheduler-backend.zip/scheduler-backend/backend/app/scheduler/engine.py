"""
Scheduler service.

Responsibilities:
  1. Recurring cron jobs: periodically scan `scheduled_jobs` for rows whose
     `next_run_at` is due, materialize a concrete `Job` (status=QUEUED), and
     advance `next_run_at` using croniter. Duplicate generation across
     multiple scheduler replicas is prevented by locking due rows with
     `SELECT ... FOR UPDATE SKIP LOCKED` and by giving each fired Job a
     deterministic idempotency_key (scheduled_job_id + fire timestamp) that
     is unique per queue.
  2. Recovery / reaper: identify jobs whose claim lease has expired (worker
     crashed after claiming or mid-execution) and safely requeue them.

Note: delayed and one-off "scheduled" jobs (job_type=DELAYED/SCHEDULED) do
NOT need a separate scheduler step -- they are created directly in QUEUED
status with a future `scheduled_at`, and the worker claim query already
filters on `scheduled_at <= now()`. Only *recurring* (cron) definitions
require this active generation loop.
"""
import asyncio
from datetime import datetime, timezone

import structlog
from croniter import croniter

from app.core.config import settings
from app.db.session import session_scope
from app.models.enums import JobStatus, JobType
from app.models.job import Job
from app.repositories.job_repo import JobRepository
from app.repositories.scheduled_job_repo import ScheduledJobRepository

logger = structlog.get_logger()


def compute_next_run(cron_expression: str, base: datetime) -> datetime:
    itr = croniter(cron_expression, base)
    return itr.get_next(datetime)


class SchedulerEngine:
    def __init__(
        self,
        *,
        poll_interval: float = settings.SCHEDULER_POLL_INTERVAL_SECONDS,
        recovery_interval: float = settings.RECOVERY_POLL_INTERVAL_SECONDS,
    ):
        self.poll_interval = poll_interval
        self.recovery_interval = recovery_interval
        self._stopping = asyncio.Event()

    def stop(self) -> None:
        self._stopping.set()

    async def run(self) -> None:
        cron_task = asyncio.create_task(self._cron_loop())
        recovery_task = asyncio.create_task(self._recovery_loop())
        await self._stopping.wait()
        cron_task.cancel()
        recovery_task.cancel()

    # ------------------------------------------------------------------
    # Recurring cron generation
    # ------------------------------------------------------------------
    async def _cron_loop(self) -> None:
        while True:
            try:
                await self._fire_due_scheduled_jobs()
            except asyncio.CancelledError:
                raise
            except Exception:
                logger.exception("scheduler_cron_loop_error")
            await asyncio.sleep(self.poll_interval)

    async def _fire_due_scheduled_jobs(self) -> int:
        fired = 0
        async with session_scope() as session:
            sched_repo = ScheduledJobRepository(session)
            job_repo = JobRepository(session)

            due = await sched_repo.find_due(limit=100)
            for sj in due:
                now = datetime.now(timezone.utc)
                fire_key = f"cron:{sj.id}:{sj.next_run_at.isoformat()}"

                existing = await job_repo.get_by_idempotency_key(sj.queue_id, fire_key)
                if existing is None:
                    job = Job(
                        queue_id=sj.queue_id,
                        job_type=JobType.RECURRING,
                        task_name=sj.task_name,
                        payload=sj.payload,
                        priority=sj.priority,
                        status=JobStatus.QUEUED,
                        scheduled_at=sj.next_run_at,
                        max_attempts=sj.max_attempts,
                        idempotency_key=fire_key,
                        scheduled_job_id=sj.id,
                    )
                    session.add(job)
                    fired += 1

                sj.last_run_at = sj.next_run_at
                sj.next_run_at = compute_next_run(sj.cron_expression, now)

        if fired:
            logger.info("scheduler_fired_jobs", count=fired)
        return fired

    # ------------------------------------------------------------------
    # Recovery / reaper for abandoned (worker-died) jobs
    # ------------------------------------------------------------------
    async def _recovery_loop(self) -> None:
        while True:
            try:
                await self._recover_abandoned_jobs()
            except asyncio.CancelledError:
                raise
            except Exception:
                logger.exception("scheduler_recovery_loop_error")
            await asyncio.sleep(self.recovery_interval)

    async def _recover_abandoned_jobs(self) -> int:
        recovered = 0
        async with session_scope() as session:
            job_repo = JobRepository(session)
            abandoned = await job_repo.find_abandoned_jobs(limit=100)
            for job in abandoned:
                logger.warning(
                    "recovering_abandoned_job", job_id=str(job.id), previous_worker_id=str(job.worker_id)
                )
                # Safe requeue: reset claim ownership so any healthy worker
                # may pick the job up again. This preserves at-least-once
                # semantics -- the previous worker may still be mid-execution
                # (network partition, GC pause) rather than truly dead, so a
                # duplicate execution is possible. See docs/worker-design.md.
                job.status = JobStatus.QUEUED  # direct assignment: recovery bypasses normal single-writer flow
                job.worker_id = None
                job.claimed_at = None
                job.started_at = None
                job.lease_expires_at = None
                recovered += 1
        if recovered:
            logger.info("scheduler_recovered_jobs", count=recovered)
        return recovered
