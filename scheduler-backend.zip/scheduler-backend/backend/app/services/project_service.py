import uuid

from sqlalchemy.ext.asyncio import AsyncSession

from app.core.exceptions import NotFoundError
from app.models.project import Project
from app.repositories.project_repo import ProjectRepository
from app.schemas.project import ProjectCreate, ProjectUpdate
from app.services.organization_service import OrganizationService, WRITE_ROLES


class ProjectService:
    def __init__(self, session: AsyncSession):
        self.session = session
        self.projects = ProjectRepository(session)
        self.org_service = OrganizationService(session)

    async def create_project(self, user_id: uuid.UUID, data: ProjectCreate) -> Project:
        await self.org_service.require_role(data.organization_id, user_id, WRITE_ROLES)
        project = Project(organization_id=data.organization_id, name=data.name, description=data.description)
        project = await self.projects.add(project)
        await self.session.commit()
        return project

    async def get_project_for_user(self, project_id: uuid.UUID, user_id: uuid.UUID) -> Project:
        project = await self.projects.get(project_id)
        if project is None:
            raise NotFoundError("Project not found", code="PROJECT_NOT_FOUND")
        # Enforce organization isolation: user must belong to the owning org.
        await self.org_service.require_membership(project.organization_id, user_id)
        return project

    async def list_projects(self, organization_id: uuid.UUID, user_id: uuid.UUID) -> list[Project]:
        await self.org_service.require_membership(organization_id, user_id)
        return await self.projects.list_for_organization(organization_id)

    async def update_project(self, project_id: uuid.UUID, user_id: uuid.UUID, data: ProjectUpdate) -> Project:
        project = await self.get_project_for_user(project_id, user_id)
        await self.org_service.require_role(project.organization_id, user_id, WRITE_ROLES)
        if data.name is not None:
            project.name = data.name
        if data.description is not None:
            project.description = data.description
        await self.session.commit()
        return project

    async def delete_project(self, project_id: uuid.UUID, user_id: uuid.UUID) -> None:
        project = await self.get_project_for_user(project_id, user_id)
        await self.org_service.require_role(project.organization_id, user_id, WRITE_ROLES)
        await self.projects.delete(project)
        await self.session.commit()
