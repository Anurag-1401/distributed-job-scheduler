import uuid

from sqlalchemy.ext.asyncio import AsyncSession

from app.core.exceptions import ForbiddenError, NotFoundError
from app.models.enums import OrgRole
from app.models.organization import Organization
from app.models.organization_member import OrganizationMember
from app.repositories.organization_repo import OrganizationMemberRepository, OrganizationRepository
from app.schemas.organization import OrganizationCreate

# Roles with permission to write (create/update/delete) within an org.
WRITE_ROLES = {OrgRole.OWNER, OrgRole.ADMIN, OrgRole.DEVELOPER}
ADMIN_ROLES = {OrgRole.OWNER, OrgRole.ADMIN}


class OrganizationService:
    def __init__(self, session: AsyncSession):
        self.session = session
        self.orgs = OrganizationRepository(session)
        self.members = OrganizationMemberRepository(session)

    async def create_organization(self, user_id: uuid.UUID, data: OrganizationCreate) -> Organization:
        org = Organization(name=data.name)
        org = await self.orgs.add(org)
        membership = OrganizationMember(organization_id=org.id, user_id=user_id, role=OrgRole.OWNER)
        await self.members.add(membership)
        await self.session.commit()
        return org

    async def list_organizations(self, user_id: uuid.UUID) -> list[Organization]:
        return await self.orgs.list_for_user(user_id)

    async def require_membership(self, organization_id: uuid.UUID, user_id: uuid.UUID) -> OrganizationMember:
        membership = await self.members.get_membership(organization_id, user_id)
        if membership is None:
            raise ForbiddenError("You do not have access to this organization", code="ORG_ACCESS_DENIED")
        return membership

    async def require_role(self, organization_id: uuid.UUID, user_id: uuid.UUID, allowed: set[OrgRole]) -> OrganizationMember:
        membership = await self.require_membership(organization_id, user_id)
        if membership.role not in allowed:
            raise ForbiddenError("You do not have permission to perform this action", code="INSUFFICIENT_ROLE")
        return membership

    async def get_organization(self, organization_id: uuid.UUID) -> Organization:
        org = await self.orgs.get(organization_id)
        if org is None:
            raise NotFoundError("Organization not found", code="ORGANIZATION_NOT_FOUND")
        return org

    async def add_member(self, organization_id: uuid.UUID, target_user_id: uuid.UUID, role: OrgRole) -> OrganizationMember:
        existing = await self.members.get_membership(organization_id, target_user_id)
        if existing is not None:
            existing.role = role
            await self.session.commit()
            return existing
        membership = OrganizationMember(organization_id=organization_id, user_id=target_user_id, role=role)
        await self.members.add(membership)
        await self.session.commit()
        return membership
