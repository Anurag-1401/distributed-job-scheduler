from datetime import datetime, timezone

from sqlalchemy.ext.asyncio import AsyncSession

from app.models.dead_letter_job import DeadLetterJob
from app.models.job import Job
from app.repositories.dlq_repo import DeadLetterJobRepository


async def move_job_to_dead_letter(
    session: AsyncSession, job: Job, *, reason: str, final_error: str | None
) -> DeadLetterJob:
    """
    Persists a DeadLetterJob record for a job whose retries are exhausted.
    Caller is responsible for transitioning job.status to DEAD_LETTER via
    the central state machine before/around calling this.
    """
    repo = DeadLetterJobRepository(session)
    entry = DeadLetterJob(
        job_id=job.id,
        worker_id=job.worker_id,
        reason=reason,
        final_error=final_error,
        attempts_made=job.attempt_count,
        original_payload=job.payload,
        failed_at=datetime.now(timezone.utc),
    )
    return await repo.add(entry)
