import uuid
from datetime import datetime, timedelta, timezone

from sqlalchemy import select, func
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.exceptions import ConflictError, InvalidStateTransitionError, NotFoundError, ValidationAppError
from app.models.enums import JOB_STATE_TRANSITIONS, JobStatus, JobType
from app.models.dead_letter_job import DeadLetterJob
from app.models.job import Job
from app.repositories.dlq_repo import DeadLetterJobRepository
from app.repositories.job_repo import JobRepository
from app.repositories.queue_repo import QueueRepository
from app.schemas.job import BatchJobCreate, BatchProgress, JobCreate
from app.services.queue_service import QueueService


def transition_job_status(job: Job, new_status: JobStatus) -> None:
    """
    Central state-machine enforcement point. Every code path that changes
    `job.status` MUST go through this function so that invalid transitions
    (e.g. COMPLETED -> RUNNING) are rejected uniformly.
    """
    allowed = JOB_STATE_TRANSITIONS.get(job.status, set())
    if new_status not in allowed:
        raise InvalidStateTransitionError(
            f"Cannot transition job from {job.status.value} to {new_status.value}",
            code="INVALID_JOB_STATE_TRANSITION",
            details={"from": job.status.value, "to": new_status.value},
        )
    job.status = new_status


class JobService:
    def __init__(self, session: AsyncSession):
        self.session = session
        self.jobs = JobRepository(session)
        self.queues = QueueRepository(session)
        self.dlq = DeadLetterJobRepository(session)
        self.queue_service = QueueService(session)

    async def create_job(self, user_id: uuid.UUID, data: JobCreate) -> Job:
        queue = await self.queue_service.get_queue_for_user(data.queue_id, user_id)

        # Idempotency: if a job with the same (queue, idempotency_key) already
        # exists, return it instead of creating a duplicate.
        if data.idempotency_key:
            existing = await self.jobs.get_by_idempotency_key(queue.id, data.idempotency_key)
            if existing is not None:
                return existing

        now = datetime.now(timezone.utc)
        if data.job_type == JobType.IMMEDIATE:
            scheduled_at = now
        elif data.job_type == JobType.DELAYED:
            scheduled_at = now + timedelta(seconds=data.delay_seconds or 0)
        elif data.job_type == JobType.SCHEDULED:
            scheduled_at = data.scheduled_at
        else:
            raise ValidationAppError(f"Unsupported job_type for direct creation: {data.job_type}")

        max_attempts = data.max_attempts
        if max_attempts is None and queue.retry_policy_id is not None:
            policy = await self.queue_service.retry_policies.get(queue.retry_policy_id)
            max_attempts = policy.max_attempts if policy else 3
        elif max_attempts is None:
            max_attempts = 3

        job = Job(
            queue_id=queue.id,
            job_type=data.job_type,
            task_name=data.task_name,
            payload=data.payload,
            priority=data.priority,
            status=JobStatus.QUEUED,
            scheduled_at=scheduled_at,
            max_attempts=max_attempts,
            idempotency_key=data.idempotency_key,
        )
        try:
            job = await self.jobs.add(job)
            await self.session.commit()
        except Exception as exc:  # unique constraint race on idempotency key
            await self.session.rollback()
            if data.idempotency_key:
                existing = await self.jobs.get_by_idempotency_key(queue.id, data.idempotency_key)
                if existing is not None:
                    return existing
            raise ConflictError("Failed to create job", code="JOB_CREATE_CONFLICT") from exc
        return job

    async def create_batch(self, user_id: uuid.UUID, data: BatchJobCreate) -> list[Job]:
        queue = await self.queue_service.get_queue_for_user(data.queue_id, user_id)
        now = datetime.now(timezone.utc)

        max_attempts = data.max_attempts
        if max_attempts is None and queue.retry_policy_id is not None:
            policy = await self.queue_service.retry_policies.get(queue.retry_policy_id)
            max_attempts = policy.max_attempts if policy else 3
        elif max_attempts is None:
            max_attempts = 3

        batch_root = Job(
            queue_id=queue.id,
            job_type=JobType.BATCH,
            task_name="__batch_root__",
            payload={"item_count": len(data.jobs)},
            priority=0,
            status=JobStatus.COMPLETED,  # root is a bookkeeping row, not executed
            scheduled_at=now,
            completed_at=now,
            max_attempts=1,
            attempt_count=0,
        )
        batch_root = await self.jobs.add(batch_root)
        await self.session.flush()

        children = []
        for item in data.jobs:
            child = Job(
                queue_id=queue.id,
                batch_id=batch_root.id,
                job_type=JobType.IMMEDIATE,
                task_name=item.task_name,
                payload=item.payload,
                priority=item.priority,
                status=JobStatus.QUEUED,
                scheduled_at=now,
                max_attempts=max_attempts,
            )
            self.session.add(child)
            children.append(child)

        await self.session.commit()
        return [batch_root, *children]

    async def get_batch_progress(self, batch_id: uuid.UUID, user_id: uuid.UUID) -> BatchProgress:
        batch_root = await self.jobs.get(batch_id)
        if batch_root is None:
            raise NotFoundError("Batch not found", code="BATCH_NOT_FOUND")
        await self.queue_service.get_queue_for_user(batch_root.queue_id, user_id)

        stmt = select(Job.status, func.count()).where(Job.batch_id == batch_id).group_by(Job.status)
        result = await self.session.execute(stmt)
        counts = {status: count for status, count in result.all()}

        total = sum(counts.values())
        completed = counts.get(JobStatus.COMPLETED, 0)
        failed = counts.get(JobStatus.FAILED, 0) + counts.get(JobStatus.DEAD_LETTER, 0)
        running = counts.get(JobStatus.CLAIMED, 0) + counts.get(JobStatus.RUNNING, 0)
        queued = counts.get(JobStatus.QUEUED, 0) + counts.get(JobStatus.RETRYING, 0) + counts.get(JobStatus.SCHEDULED, 0)
        other = total - completed - failed - running - queued

        return BatchProgress(
            batch_id=batch_id, total=total, completed=completed, failed=failed,
            running=running, queued=queued, other=max(0, other),
        )

    async def get_job_for_user(self, job_id: uuid.UUID, user_id: uuid.UUID) -> Job:
        job = await self.jobs.get(job_id)
        if job is None:
            raise NotFoundError("Job not found", code="JOB_NOT_FOUND")
        await self.queue_service.get_queue_for_user(job.queue_id, user_id)
        return job

    async def list_jobs(self, user_id: uuid.UUID, **filters) -> tuple[list[Job], int]:
        queue_id = filters.get("queue_id")
        if queue_id is not None:
            await self.queue_service.get_queue_for_user(queue_id, user_id)
        return await self.jobs.list_filtered(**filters)

    async def cancel_job(self, job_id: uuid.UUID, user_id: uuid.UUID) -> Job:
        job = await self.get_job_for_user(job_id, user_id)
        transition_job_status(job, JobStatus.CANCELLED)
        await self.session.commit()
        return job

    async def retry_dead_letter_job(self, dlq_id: uuid.UUID, user_id: uuid.UUID) -> Job:
        dlq_entry = await self.dlq.get(dlq_id)
        if dlq_entry is None:
            raise NotFoundError("Dead letter entry not found", code="DLQ_NOT_FOUND")
        job = await self.get_job_for_user(dlq_entry.job_id, user_id)

        transition_job_status(job, JobStatus.QUEUED)
        job.scheduled_at = datetime.now(timezone.utc)
        job.attempt_count = 0
        job.worker_id = None
        job.claimed_at = None
        job.lease_expires_at = None
        await self.session.commit()
        return job

    async def list_dlq(self, user_id: uuid.UUID, *, archived: bool | None = None, limit: int = 20, offset: int = 0):
        # Access control note: DLQ listing is currently org-wide via job
        # ownership checks performed on retrieval; a production system would
        # scope this query by organization directly for efficiency.
        return await self.dlq.list_filtered(archived=archived, limit=limit, offset=offset)

    async def archive_dlq(self, dlq_id: uuid.UUID, user_id: uuid.UUID) -> DeadLetterJob:
        dlq_entry = await self.dlq.get(dlq_id)
        if dlq_entry is None:
            raise NotFoundError("Dead letter entry not found", code="DLQ_NOT_FOUND")
        await self.get_job_for_user(dlq_entry.job_id, user_id)
        dlq_entry.archived = True
        await self.session.commit()
        return dlq_entry
