from sqlalchemy.ext.asyncio import AsyncSession

from app.core.exceptions import ConflictError, UnauthorizedError
from app.core.security import create_access_token, hash_password, verify_password
from app.models.user import User
from app.repositories.user_repo import UserRepository
from app.schemas.auth import UserLogin, UserRegister


class AuthService:
    def __init__(self, session: AsyncSession):
        self.session = session
        self.users = UserRepository(session)

    async def register(self, data: UserRegister) -> User:
        existing = await self.users.get_by_email(data.email)
        if existing is not None:
            raise ConflictError("A user with this email already exists", code="USER_EXISTS")

        user = User(email=data.email, password_hash=hash_password(data.password), name=data.name)
        user = await self.users.add(user)
        await self.session.commit()
        return user

    async def authenticate(self, data: UserLogin) -> tuple[User, str]:
        user = await self.users.get_by_email(data.email)
        if user is None or not verify_password(data.password, user.password_hash):
            raise UnauthorizedError("Invalid email or password", code="INVALID_CREDENTIALS")
        if not user.is_active:
            raise UnauthorizedError("User account is disabled", code="USER_DISABLED")

        token = create_access_token(subject=user.id)
        return user, token
