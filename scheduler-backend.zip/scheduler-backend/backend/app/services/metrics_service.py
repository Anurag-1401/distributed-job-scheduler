from sqlalchemy import select, func
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.enums import JobStatus, WorkerStatus
from app.models.job import Job
from app.models.worker import Worker


class MetricsService:
    def __init__(self, session: AsyncSession):
        self.session = session

    async def overview(self) -> dict:
        status_stmt = select(Job.status, func.count()).group_by(Job.status)
        status_counts = dict((await self.session.execute(status_stmt)).all())

        worker_stmt = select(Worker.status, func.count()).group_by(Worker.status)
        worker_counts = dict((await self.session.execute(worker_stmt)).all())

        return {
            "jobs_by_status": {s.value if hasattr(s, "value") else s: c for s, c in status_counts.items()},
            "workers_by_status": {s.value if hasattr(s, "value") else s: c for s, c in worker_counts.items()},
            "total_jobs": sum(status_counts.values()),
            "total_workers": sum(worker_counts.values()),
        }
