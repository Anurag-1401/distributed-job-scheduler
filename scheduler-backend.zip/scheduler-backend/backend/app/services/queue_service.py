import uuid
from datetime import datetime, timedelta, timezone

from sqlalchemy import select, func
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.exceptions import ConflictError, NotFoundError
from app.models.enums import JobStatus, QueueStatus, ExecutionStatus
from app.models.job import Job
from app.models.job_execution import JobExecution
from app.models.queue import Queue
from app.repositories.queue_repo import QueueRepository, RetryPolicyRepository
from app.schemas.queue import QueueCreate, QueueUpdate, QueueStats
from app.services.project_service import ProjectService
from app.services.organization_service import WRITE_ROLES


class QueueService:
    def __init__(self, session: AsyncSession):
        self.session = session
        self.queues = QueueRepository(session)
        self.retry_policies = RetryPolicyRepository(session)
        self.project_service = ProjectService(session)

    async def create_queue(self, user_id: uuid.UUID, data: QueueCreate) -> Queue:
        project = await self.project_service.get_project_for_user(data.project_id, user_id)
        await self.project_service.org_service.require_role(project.organization_id, user_id, WRITE_ROLES)

        queue = Queue(
            project_id=data.project_id,
            name=data.name,
            priority=data.priority,
            concurrency_limit=data.concurrency_limit,
            retry_policy_id=data.retry_policy_id,
        )
        try:
            queue = await self.queues.add(queue)
            await self.session.commit()
        except IntegrityError as exc:
            await self.session.rollback()
            raise ConflictError(
                f"A queue named '{data.name}' already exists in this project", code="QUEUE_NAME_CONFLICT"
            ) from exc
        return queue

    async def get_queue_for_user(self, queue_id: uuid.UUID, user_id: uuid.UUID) -> Queue:
        queue = await self.queues.get(queue_id)
        if queue is None:
            raise NotFoundError("Queue not found", code="QUEUE_NOT_FOUND")
        await self.project_service.get_project_for_user(queue.project_id, user_id)
        return queue

    async def list_queues(self, project_id: uuid.UUID, user_id: uuid.UUID) -> list[Queue]:
        await self.project_service.get_project_for_user(project_id, user_id)
        return await self.queues.list_for_project(project_id)

    async def update_queue(self, queue_id: uuid.UUID, user_id: uuid.UUID, data: QueueUpdate) -> Queue:
        queue = await self.get_queue_for_user(queue_id, user_id)
        project = await self.project_service.projects.get(queue.project_id)
        await self.project_service.org_service.require_role(project.organization_id, user_id, WRITE_ROLES)

        if data.name is not None:
            queue.name = data.name
        if data.priority is not None:
            queue.priority = data.priority
        if data.concurrency_limit is not None:
            queue.concurrency_limit = data.concurrency_limit
        if data.retry_policy_id is not None:
            queue.retry_policy_id = data.retry_policy_id
        await self.session.commit()
        return queue

    async def set_status(self, queue_id: uuid.UUID, user_id: uuid.UUID, status: QueueStatus) -> Queue:
        queue = await self.get_queue_for_user(queue_id, user_id)
        project = await self.project_service.projects.get(queue.project_id)
        await self.project_service.org_service.require_role(project.organization_id, user_id, WRITE_ROLES)
        queue.status = status
        await self.session.commit()
        return queue

    async def get_stats(self, queue_id: uuid.UUID, user_id: uuid.UUID) -> QueueStats:
        queue = await self.get_queue_for_user(queue_id, user_id)

        async def count_status(status: JobStatus) -> int:
            stmt = select(func.count()).select_from(Job).where(Job.queue_id == queue.id, Job.status == status)
            result = await self.session.execute(stmt)
            return result.scalar_one()

        queued = await count_status(JobStatus.QUEUED)
        scheduled = await count_status(JobStatus.SCHEDULED)
        running = (await count_status(JobStatus.CLAIMED)) + (await count_status(JobStatus.RUNNING))
        completed = await count_status(JobStatus.COMPLETED)
        failed = await count_status(JobStatus.FAILED)
        dead_letter = await count_status(JobStatus.DEAD_LETTER)

        one_min_ago = datetime.now(timezone.utc) - timedelta(minutes=1)
        throughput_stmt = select(func.count()).select_from(Job).where(
            Job.queue_id == queue.id, Job.status == JobStatus.COMPLETED, Job.completed_at >= one_min_ago
        )
        throughput = (await self.session.execute(throughput_stmt)).scalar_one()

        avg_stmt = (
            select(func.avg(JobExecution.duration_ms))
            .join(Job, Job.id == JobExecution.job_id)
            .where(Job.queue_id == queue.id, JobExecution.status == ExecutionStatus.SUCCEEDED)
        )
        avg_duration = (await self.session.execute(avg_stmt)).scalar_one()

        return QueueStats(
            queue_id=queue.id,
            queued=queued,
            scheduled=scheduled,
            running=running,
            completed=completed,
            failed=failed,
            dead_letter=dead_letter,
            throughput_per_minute=float(throughput),
            avg_execution_time_ms=float(avg_duration) if avg_duration is not None else None,
        )
