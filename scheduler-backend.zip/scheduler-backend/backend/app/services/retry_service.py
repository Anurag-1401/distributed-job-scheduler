"""
Retry / backoff calculation.

Given a retry policy and the attempt number that just failed, computes the
delay (in seconds) before the job becomes eligible again.

    FIXED:       base_delay, base_delay, base_delay, ...
    LINEAR:      base_delay * n
    EXPONENTIAL: base_delay * 2^(n-1)

All strategies are capped at `max_delay_seconds` and, when `jitter` is
enabled, a random +/-20% jitter is applied to reduce retry storms (thundering
herd) when many jobs fail around the same time.
"""
import random

from app.models.enums import RetryBackoffStrategy


def compute_backoff_seconds(
    *,
    strategy: RetryBackoffStrategy,
    attempt_number: int,
    base_delay_seconds: float,
    max_delay_seconds: float,
    jitter: bool = True,
) -> float:
    if attempt_number < 1:
        attempt_number = 1

    if strategy == RetryBackoffStrategy.FIXED:
        delay = base_delay_seconds
    elif strategy == RetryBackoffStrategy.LINEAR:
        delay = base_delay_seconds * attempt_number
    elif strategy == RetryBackoffStrategy.EXPONENTIAL:
        delay = base_delay_seconds * (2 ** (attempt_number - 1))
    else:
        raise ValueError(f"Unknown backoff strategy: {strategy}")

    delay = min(delay, max_delay_seconds)

    if jitter:
        jitter_range = delay * 0.2
        delay = delay + random.uniform(-jitter_range, jitter_range)
        delay = max(0.0, delay)

    return delay
