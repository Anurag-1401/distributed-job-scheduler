import uuid
from datetime import datetime, timezone

from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.core.exceptions import NotFoundError
from app.models.worker import Worker
from app.models.worker_heartbeat import WorkerHeartbeat
from app.models.enums import WorkerStatus
from app.repositories.worker_repo import WorkerHeartbeatRepository, WorkerRepository
from app.schemas.worker import WorkerHeartbeatIn, WorkerOut, WorkerRegister


class WorkerService:
    def __init__(self, session: AsyncSession):
        self.session = session
        self.workers = WorkerRepository(session)
        self.heartbeats = WorkerHeartbeatRepository(session)

    async def register(self, data: WorkerRegister) -> Worker:
        existing = await self.workers.get_by_key(data.worker_key)
        now = datetime.now(timezone.utc)
        if existing is not None:
            existing.status = WorkerStatus.ONLINE
            existing.hostname = data.hostname
            existing.registered_at = now
            await self.session.commit()
            return existing

        worker = Worker(
            worker_key=data.worker_key,
            hostname=data.hostname,
            status=WorkerStatus.ONLINE,
            registered_at=now,
        )
        worker = await self.workers.add(worker)
        await self.session.commit()
        return worker

    async def record_heartbeat(self, worker_id: uuid.UUID, data: WorkerHeartbeatIn) -> Worker:
        worker = await self.workers.get(worker_id)
        if worker is None:
            raise NotFoundError("Worker not found", code="WORKER_NOT_FOUND")

        now = datetime.now(timezone.utc)
        worker.last_heartbeat_at = now
        worker.status = data.status

        hb = WorkerHeartbeat(
            worker_id=worker_id,
            heartbeat_at=now,
            status=data.status.value,
            current_job_count=data.current_job_count,
            meta=data.meta,
        )
        await self.heartbeats.add(hb)
        await self.session.commit()
        return worker

    async def list_workers(self) -> list[WorkerOut]:
        workers = await self.workers.list_all()
        out = []
        for w in workers:
            is_healthy = WorkerRepository.is_healthy(w, settings.WORKER_HEARTBEAT_TIMEOUT_SECONDS)
            item = WorkerOut.model_validate(w)
            item.is_healthy = is_healthy
            out.append(item)
        return out

    async def get_worker(self, worker_id: uuid.UUID) -> Worker:
        worker = await self.workers.get(worker_id)
        if worker is None:
            raise NotFoundError("Worker not found", code="WORKER_NOT_FOUND")
        return worker

    async def mark_offline_if_stale(self) -> int:
        """Mark workers whose heartbeat has expired as OFFLINE. Returns count updated."""
        workers = await self.workers.list_all()
        updated = 0
        for w in workers:
            if w.status != WorkerStatus.OFFLINE and not WorkerRepository.is_healthy(w, settings.WORKER_HEARTBEAT_TIMEOUT_SECONDS):
                w.status = WorkerStatus.OFFLINE
                updated += 1
        if updated:
            await self.session.commit()
        return updated
