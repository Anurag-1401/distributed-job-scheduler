# Retry Strategy

## Backoff strategies

Implemented in `app.services.retry_service.compute_backoff_seconds`.

| Strategy | Formula (attempt `n`, 1-indexed) | Example (base=10s / base=2s) |
|---|---|---|
| `FIXED` | `base_delay` | 10s, 10s, 10s, 10s |
| `LINEAR` | `base_delay * n` | 10s, 20s, 30s, 40s |
| `EXPONENTIAL` | `base_delay * 2^(n-1)` | 2s, 4s, 8s, 16s |

All strategies are capped at `max_delay_seconds`. When `jitter=True` (the
default), a uniform random +/-20% jitter is applied to the computed delay to
avoid many simultaneously-failing jobs retrying in lockstep (a "retry
storm"/thundering herd against a downstream dependency).

```mermaid
flowchart LR
    F[FAILED] --> Check{attempt_count >= max_attempts?}
    Check -- yes --> DLQ[DEAD_LETTER]
    Check -- no --> Compute[compute_backoff_seconds]
    Compute --> Requeue["QUEUED with scheduled_at = now + delay"]
```

## Configuration

Retry behavior is configured per-queue via an optional `retry_policies` row
(`strategy`, `max_attempts`, `base_delay_seconds`, `max_delay_seconds`, `jitter`).
A queue without an assigned retry policy falls back to
`EXPONENTIAL, max_attempts=3, base_delay=2s, max_delay=300s, jitter=True`.
`max_attempts` can also be overridden per-job at creation time.

## Dead-letter queue

When `job.attempt_count >= job.max_attempts` after a failed attempt, the job
transitions `FAILED -> DEAD_LETTER` and a `dead_letter_jobs` row is written
capturing:

- the original job reference and payload
- `reason` and `final_error`
- `attempts_made`
- `failed_at` timestamp
- the worker that made the final attempt

DLQ entries can be listed, inspected, manually retried (`POST
/api/v1/dlq/{id}/retry`, which resets `attempt_count` to 0 and requeues the
job), or archived (`DELETE /api/v1/dlq/{id}`, a soft-delete that sets
`archived=true` rather than physically deleting the audit record).

## Why capped + jittered exponential is the sane default

Exponential backoff quickly backs off from a struggling downstream
dependency without needing manual tuning per failure type, the cap prevents
unbounded wait times for long-lived queues, and jitter decorrelates
simultaneous retries so a batch of jobs that all failed together (e.g. due to
a brief outage) don't all retry at the exact same instant and re-cause the
outage.
