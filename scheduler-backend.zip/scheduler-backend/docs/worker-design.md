# Worker Design

## Process model

Each worker is a standalone async Python process (`python -m app.workers.worker_main`),
independently deployable and horizontally scalable
(`docker compose up --scale worker=3`). A worker has no shared in-memory state
with other workers — all coordination happens through PostgreSQL.

```mermaid
flowchart TD
    Start([Process start]) --> Register[Register worker row]
    Register --> Heartbeat[Start heartbeat loop]
    Register --> Poll[Start poll loop]
    Poll --> CheckSem{Concurrency slot free?}
    CheckSem -- no --> Sleep[Sleep poll_interval]
    CheckSem -- yes --> Claim[Atomically claim next eligible job per active queue]
    Claim -- none found --> Sleep
    Claim -- claimed --> Dispatch[Dispatch async execution task]
    Dispatch --> Poll
    Sleep --> Poll

    Signal([SIGINT/SIGTERM]) --> StopClaiming[Stop poll loop]
    StopClaiming --> WaitInFlight[Wait for in-flight jobs, up to shutdown_timeout]
    WaitInFlight --> MarkOffline[Mark worker OFFLINE]
    MarkOffline --> Exit([Exit])
```

## Concurrency control

Each worker holds an `asyncio.Semaphore(max_concurrency)` bounding how many
jobs *that worker* executes simultaneously. Independently, before claiming,
the worker checks the **queue's** current `CLAIMED + RUNNING` count against
`queue.concurrency_limit` and skips claiming from that queue if the limit is
already reached. Because the claim itself is also atomic and transactional,
these two checks compose correctly: a queue configured with
`concurrency_limit = 5` will never have more than 5 jobs simultaneously
claimed/running, regardless of how many workers or how much worker-level
concurrency is deployed.

Task execution runs **outside** any open database transaction/connection —
the claim transaction commits immediately after marking the job `CLAIMED`,
and a fresh, short transaction is used to persist the final `RUNNING`/`COMPLETED`/`FAILED`
result. This prevents a slow or hanging task from holding a database
connection or row lock for its entire duration.

## Heartbeats

Every `WORKER_HEARTBEAT_INTERVAL_SECONDS` (default 5s), a worker:

1. Updates `workers.last_heartbeat_at` and `workers.status`.
2. Inserts a `worker_heartbeats` row recording `current_job_count` for
   historical/observability purposes.

A worker is considered healthy if `now() - last_heartbeat_at <=
WORKER_HEARTBEAT_TIMEOUT_SECONDS` (default 20s, i.e. 4 missed heartbeats).
`GET /api/v1/workers` reports `is_healthy` computed from this rule.

## Failure recovery (the reaper)

Every claimed job is given a `lease_expires_at = claimed_at + JOB_LEASE_SECONDS`
(default 60s). The scheduler process runs a recovery loop
(`RECOVERY_POLL_INTERVAL_SECONDS`, default 10s) that:

1. Selects all `CLAIMED`/`RUNNING` jobs whose lease has expired
   (`FOR UPDATE SKIP LOCKED`, so multiple scheduler replicas cooperate safely).
2. Resets them to `QUEUED`, clearing `worker_id`/`claimed_at`/`lease_expires_at`,
   making them immediately eligible for any healthy worker to reclaim.

```mermaid
sequenceDiagram
    participant W1 as Worker 1 (crashes)
    participant DB as PostgreSQL
    participant S as Scheduler (recovery loop)
    participant W2 as Worker 2

    W1->>DB: claims Job X (lease = now + 60s)
    Note over W1: process crashes mid-execution
    S->>DB: SELECT jobs WHERE lease_expires_at < now()
    DB-->>S: Job X (lease expired)
    S->>DB: UPDATE Job X SET status=QUEUED, worker_id=NULL
    W2->>DB: claims Job X
    W2->>W2: executes task (again)
```

This is why the system is at-least-once, not exactly-once: Worker 1 might
not actually be dead (e.g. a long GC pause or network partition), so Job X
could theoretically still be running on Worker 1 when Worker 2 picks it up.
Choosing `JOB_LEASE_SECONDS` well above the expected p99 task duration
minimizes (but cannot eliminate) this risk.

## Graceful shutdown

On `SIGINT`/`SIGTERM`, a worker:

1. Immediately stops polling for new work.
2. Waits for in-flight executions to finish naturally, up to
   `WORKER_GRACEFUL_SHUTDOWN_TIMEOUT_SECONDS` (default 30s).
3. Cancels any executions still running past the timeout (their lease will
   subsequently expire and they'll be recovered normally).
4. Marks its `workers` row `OFFLINE` and exits.

## Task execution sandboxing

Workers execute jobs by looking up `job.task_name` in a fixed registry
(`app.tasks.registry`) of developer-defined async functions. The API never
accepts executable code in a job payload — only JSON data passed as an
argument to a pre-registered handler. This is a deliberate security boundary:
job payloads can never achieve remote code execution against a worker.
