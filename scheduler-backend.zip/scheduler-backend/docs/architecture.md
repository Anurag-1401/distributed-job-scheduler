# Architecture

## Overview

The system is a distributed background job scheduling platform composed of four
independently deployable processes that all share the same codebase and database:

1. **API** (`app.main:app`) — a FastAPI application handling all synchronous
   CRUD/read operations (auth, organizations, projects, queues, jobs, DLQ, metrics).
2. **Worker** (`app.workers.worker_main`) — polls queues, atomically claims jobs,
   executes them, and records results. Horizontally scalable
   (`docker compose up --scale worker=3`).
3. **Scheduler** (`app.scheduler.scheduler_main`) — fires due recurring (cron)
   jobs and recovers jobs abandoned by crashed workers.
4. **Migrate** — a one-shot Alembic job that applies schema migrations before
   the other services start.

```mermaid
flowchart TB
    Client[API Client] -->|HTTPS| API[FastAPI API]
    API --> PG[(PostgreSQL)]
    API -.optional.-> Redis[(Redis)]

    Scheduler[Scheduler Service] --> PG
    Worker1[Worker 1] --> PG
    Worker2[Worker 2] --> PG
    WorkerN[Worker N] --> PG
```

## Why PostgreSQL is the source of truth, and what Redis is for

PostgreSQL is the **only** system of record for persistent job state (jobs,
executions, logs, worker registry, DLQ). All correctness-critical operations —
atomic job claiming, state transitions, retry bookkeeping — happen inside
PostgreSQL transactions.

Redis is wired into the stack (connection is configured and available to all
services) as fast supporting infrastructure for things that are **not**
correctness-critical: e.g. caching read-heavy metrics, short-lived rate-limit
counters shared across API replicas, or pub/sub notifications for future
real-time features (WebSocket job updates). The system must continue to
function correctly (at reduced performance) if Redis is unavailable — nothing
depends on Redis as its only copy of state. In the current implementation, the
in-process rate limiter is used by default; the Redis client is available for
services to opt into as the deployment scales beyond a single API replica.

## Modular layering

```
app/
├── api/v1/        # FastAPI routers — HTTP concerns only, thin
├── services/       # business logic, authorization checks, orchestration
├── repositories/    # data-access layer — all raw SQLAlchemy queries live here
├── models/         # SQLAlchemy ORM table definitions
├── schemas/        # Pydantic request/response models
├── workers/        # worker engine + process entrypoint
├── scheduler/       # scheduler engine (cron + recovery) + process entrypoint
├── tasks/          # sandboxed task registry (echo, http_request, sleep, ...)
├── core/           # config, security, exceptions, logging, DI
└── db/             # engine/session management
```

Route handlers depend only on services; services depend only on repositories;
repositories are the only layer that issues SQL. This keeps business logic
out of HTTP handlers and out of raw SQL, and makes each layer independently
testable.

## Request flow example: creating and running a job

```mermaid
sequenceDiagram
    participant C as Client
    participant API as FastAPI API
    participant DB as PostgreSQL
    participant W as Worker

    C->>API: POST /api/v1/jobs
    API->>DB: INSERT job (status=QUEUED)
    API-->>C: 201 Created

    loop poll loop
        W->>DB: SELECT ... FOR UPDATE SKIP LOCKED
        DB-->>W: claims 1 job (status=CLAIMED)
    end
    W->>DB: UPDATE job SET status=RUNNING
    W->>W: execute registered task handler
    W->>DB: INSERT job_execution, UPDATE job status=COMPLETED/FAILED
```

## Key design trade-offs

| Decision | Trade-off |
|---|---|
| PostgreSQL row locking (`FOR UPDATE SKIP LOCKED`) for claiming | Simple, transactional, no extra infra — but claim throughput is bounded by DB connection/lock contention at very high job rates. Acceptable for this scale; a message-broker-based claim (SQS/Kafka) would scale further but sacrifices the single-source-of-truth simplicity. |
| At-least-once execution (not exactly-once) | Guaranteeing exactly-once distributed execution generally requires either idempotent side effects or a two-phase commit with the downstream system, which is outside this system's control. We provide idempotency keys and lease-based recovery to make at-least-once safe in practice. |
| Worker-side task registry instead of arbitrary code execution | Prevents remote code execution from job payloads; limits task types to what's explicitly registered by developers. |
| Recovery via lease expiry, not process monitoring | Simpler and works across process/host boundaries without needing a separate service discovery mechanism; costs a fixed lease-timeout worth of latency before a truly-dead worker's job is retried. |
