# Database Design

All tables use UUID primary keys, `created_at`/`updated_at` timestamps
(except append-only `job_executions`, `job_logs`, `worker_heartbeats` which
only need `created_at`-equivalent timing columns), foreign keys with explicit
`ondelete` behavior, and indexes chosen to match actual query patterns
(claim lookups, filtering, pagination).

## Entity-relationship overview

```mermaid
erDiagram
    USERS ||--o{ ORGANIZATION_MEMBERS : has
    ORGANIZATIONS ||--o{ ORGANIZATION_MEMBERS : has
    ORGANIZATIONS ||--o{ PROJECTS : owns
    PROJECTS ||--o{ QUEUES : contains
    RETRY_POLICIES ||--o{ QUEUES : "configures (optional)"
    QUEUES ||--o{ JOBS : contains
    QUEUES ||--o{ SCHEDULED_JOBS : contains
    SCHEDULED_JOBS ||--o{ JOBS : generates
    JOBS ||--o{ JOB_EXECUTIONS : "has attempts"
    JOBS ||--o{ JOB_LOGS : "has logs"
    JOBS ||--o| DEAD_LETTER_JOBS : "moves to (on exhaustion)"
    JOBS }o--o| JOBS : "batch children -> batch root"
    WORKERS ||--o{ JOB_EXECUTIONS : executes
    WORKERS ||--o{ WORKER_HEARTBEATS : sends
    WORKERS ||--o{ JOBS : claims
```

## Table notes

### `users`
Unique index on `email`. Passwords stored only as Argon2 hashes (`password_hash`).

### `organizations` / `organization_members`
`organization_members` is the join table carrying `role` (OWNER/ADMIN/DEVELOPER/VIEWER).
Unique constraint on `(organization_id, user_id)` prevents duplicate memberships.

### `projects`
Belongs to exactly one organization. All project access is gated on
organization membership (see `docs/design-decisions.md`).

### `queues`
`(project_id, name)` is unique so queue names are human-friendly and
non-ambiguous within a project. `retry_policy_id` is nullable — queues
without one fall back to sane defaults (exponential, 3 attempts) applied at
job-creation time.

### `jobs`
The central table. Notable columns:

- `scheduled_at` — when the job becomes eligible (used for IMMEDIATE = now,
  DELAYED = now + delay, SCHEDULED = explicit time, RECURRING = cron fire time).
- `worker_id` / `claimed_at` / `lease_expires_at` — claim ownership and lease,
  used by the recovery/reaper process to detect abandoned jobs.
- `idempotency_key` — combined with a unique constraint on
  `(queue_id, idempotency_key)` to make job creation idempotent.
- `batch_id` — self-referential FK; batch child jobs point at a root "batch"
  job row used purely for progress bookkeeping.

**Composite index `ix_jobs_claim_lookup` on `(queue_id, status, scheduled_at)`**
directly backs the atomic claim query:

```sql
SELECT * FROM jobs
WHERE queue_id = :queue_id AND status = 'QUEUED' AND scheduled_at <= now()
ORDER BY priority DESC, scheduled_at ASC
LIMIT 1
FOR UPDATE SKIP LOCKED;
```

### `job_executions`
Append-only — one row per attempt, never updated after `completed_at` is set
except to correct the terminal status. Unique on `(job_id, attempt_number)`.
This preserves full execution history even across many retries.

### `job_logs`
Structured log lines linked to a job and optionally a specific execution
attempt, with `level` (DEBUG/INFO/WARNING/ERROR).

### `workers` / `worker_heartbeats`
`workers.last_heartbeat_at` is a denormalized "latest heartbeat" column for
fast health checks; `worker_heartbeats` retains the full history for
observability/debugging.

### `scheduled_jobs`
Cron definitions. `next_run_at` is advanced every time the scheduler fires
the definition. Firing is made idempotent by giving each generated `Job` a
deterministic `idempotency_key` of `cron:{scheduled_job_id}:{fire_time_iso}`.

### `dead_letter_jobs`
One row per job that exhausted retries, unique on `job_id`. Retains the
`original_payload` and `attempts_made` for audit/replay.

## Why not automatic table creation

Production startup never calls `Base.metadata.create_all()`. All schema
changes go through Alembic migrations (`alembic/versions/`) so that schema
evolution is versioned, reviewable, and reversible, and so that migrations
can run as a separate, auditable step (`docker-compose`'s `migrate` service)
before application code that depends on the new schema is deployed.
