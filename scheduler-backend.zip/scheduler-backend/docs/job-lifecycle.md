# Job Lifecycle

## States

| State | Meaning |
|---|---|
| `SCHEDULED` | Reserved for future use where a job is defined but not yet eligible to queue (currently DELAYED/SCHEDULED jobs go straight to QUEUED with a future `scheduled_at`; see note below). |
| `QUEUED` | Eligible for claiming once `scheduled_at <= now()` and the queue is ACTIVE. |
| `CLAIMED` | A worker has atomically locked and taken ownership of the job; not yet executing. |
| `RUNNING` | The worker has started executing the task handler. |
| `COMPLETED` | Task handler returned successfully. Terminal. |
| `FAILED` | The current attempt's task handler raised an exception. Transient — immediately followed by a transition to `RETRYING` or `DEAD_LETTER`. |
| `RETRYING` | Bookkeeping state entered en route back to `QUEUED` with a future `scheduled_at` computed by the retry engine. |
| `CANCELLED` | User-cancelled. Terminal. |
| `DEAD_LETTER` | Retries exhausted; moved to the dead-letter queue. Can be manually retried back to `QUEUED`. |

> **Note:** In this implementation, jobs of type DELAYED/SCHEDULED are created
> directly in `QUEUED` status with a future `scheduled_at`; the claim query's
> `scheduled_at <= now()` filter naturally defers eligibility. The `SCHEDULED`
> state is retained in the state machine and enum for systems that want an
> explicit "not yet queued" holding state before a job is released into the
> queue (e.g. an approval step) — the state machine already allows
> `SCHEDULED -> QUEUED`.

## State machine diagram

```mermaid
stateDiagram-v2
    [*] --> SCHEDULED
    [*] --> QUEUED
    SCHEDULED --> QUEUED
    SCHEDULED --> CANCELLED
    QUEUED --> CLAIMED: worker atomically claims (FOR UPDATE SKIP LOCKED)
    QUEUED --> CANCELLED
    CLAIMED --> RUNNING: worker starts task handler
    CLAIMED --> QUEUED: lease expired, recovered by reaper
    CLAIMED --> CANCELLED
    RUNNING --> COMPLETED: handler succeeded
    RUNNING --> FAILED: handler raised
    RUNNING --> CANCELLED
    RUNNING --> QUEUED: lease expired, recovered by reaper
    FAILED --> RETRYING: attempts remain
    FAILED --> DEAD_LETTER: attempts exhausted
    RETRYING --> QUEUED: backoff delay elapsed
    RETRYING --> CANCELLED
    DEAD_LETTER --> QUEUED: manual retry via API
    COMPLETED --> [*]
    CANCELLED --> [*]
```

## Enforcement

Every status change goes through
`app.services.job_service.transition_job_status(job, new_status)`, which
consults a single source-of-truth transition table
(`app.models.enums.JOB_STATE_TRANSITIONS`) and raises
`InvalidStateTransitionError` (HTTP 409) for any transition not explicitly
allowed. This guarantees the state machine is enforced identically whether
the transition originates from the API, the worker engine, or the scheduler's
recovery loop.

## Delivery semantics: at-least-once

This system provides **at-least-once** execution, not exactly-once:

- A job is only removed from the "needs execution" pool once its status is
  durably `COMPLETED`.
- If a worker crashes *after* successfully running the task's side effects
  but *before* the `COMPLETED` write commits, the job's lease will
  eventually expire and the recovery process will requeue it — causing the
  task to run again.
- Task handlers that have externally-visible side effects (sending an email,
  charging a card, calling a third-party API) should be written to be
  idempotent, or should use the job's `idempotency_key` / a
  request-level idempotency key of their own to detect duplicate execution
  downstream.

We do not claim exactly-once execution anywhere in this system, in code
comments, or in API documentation, because it is not genuinely guaranteed.
