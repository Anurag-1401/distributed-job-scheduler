# Design Decisions

## PostgreSQL vs Redis responsibilities

**Decision:** PostgreSQL is the sole source of truth for all persistent job
state. Redis is available as fast supporting infrastructure but nothing
depends on it as the only copy of correctness-critical data.

**Why:** Job scheduling correctness (no double-claims, no lost jobs, accurate
retry counts) requires ACID transactions and row-level locking that
PostgreSQL provides natively. Using Redis as the primary job store would
require reimplementing transactional guarantees (e.g. via Lua scripts or
Redis transactions) that PostgreSQL already gives us, while giving up
PostgreSQL's mature tooling (migrations, foreign keys, query planner,
backups). The trade-off is that claim throughput is bounded by PostgreSQL's
write capacity — acceptable at the scale this system targets, and a well
understood scaling path (read replicas for reporting queries, partitioning
`jobs`/`job_executions` by time, sharding by queue) exists if needed later.

## Atomic job claiming: `SELECT ... FOR UPDATE SKIP LOCKED`

**Decision:** Use row-level locking with `SKIP LOCKED` rather than
application-level mutexes, advisory locks per job, or a separate
message-broker-based claim (e.g. SQS visibility timeout, Kafka consumer
groups).

**Why:** `FOR UPDATE SKIP LOCKED` gives exactly the semantics needed —
concurrent workers each grab a different unlocked row instead of blocking on
each other — in a single SQL statement, inside the same transaction that also
enforces queue status, priority ordering, and scheduling eligibility. No
additional infrastructure, no distributed lock service, and it composes
naturally with the rest of the job's transactional lifecycle. Verified with
concurrent-worker tests (`tests/concurrency/test_atomic_claim.py`).

## At-least-once execution

**Decision:** Document and design for at-least-once delivery; do not claim
exactly-once anywhere.

**Why:** True exactly-once execution across a network boundary (worker crash
mid-task) is impossible to guarantee in general without either (a) the task's
side effect being transactionally tied to the job's status update (not
possible for external side effects like sending an email), or (b) idempotent
task design combined with deduplication downstream. We provide the building
blocks — idempotency keys, lease-based recovery — but leave idempotent task
design to task authors, since only they know what "duplicate" means for
their specific side effect.

## Worker failure recovery via lease expiry

**Decision:** Detect abandoned jobs by a `lease_expires_at` timestamp checked
by a periodic reaper, rather than active health-checking of specific worker
processes.

**Why:** Lease expiry works uniformly regardless of *how* a worker died
(process crash, host failure, network partition, OOM kill) without needing
the recovery process to reach the worker at all. The cost is a fixed
worst-case detection latency of `JOB_LEASE_SECONDS`, which is tunable per
deployment.

## Retry strategy: capped, jittered backoff

See `docs/retry-strategy.md` for the full rationale — summary: exponential
backoff with a cap and +/-20% jitter is the standard, well-tested default
that balances quick recovery from transient failures against not
overwhelming a struggling downstream dependency.

## Concurrency limits enforced at claim time + application check

**Decision:** Enforce `queue.concurrency_limit` via an application-level
count check (`CLAIMED + RUNNING` count for that queue) performed just before
attempting to claim, combined with the atomicity of the claim itself.

**Why:** A pure database CHECK constraint on "count of CLAIMED+RUNNING rows
per queue_id" is awkward to express and enforce transactionally in
PostgreSQL without either a materialized counter (extra write contention) or
a `SELECT COUNT(*) ... FOR UPDATE` pattern that would serialize all claims
for a queue on every attempt. The chosen approach — check-then-claim inside
the worker's poll loop — is simple, is verified under real concurrent load in
`tests/concurrency/test_queue_concurrency.py`, and the tiny race window
(check and claim are two statements, not one) is self-correcting: at worst
one queue briefly exceeds its limit by the number of workers racing at that
exact instant, which is bounded and negligible for realistic concurrency
limits and worker counts. A stricter guarantee could be added later with a
Postgres advisory lock per queue around the check-and-claim pair, at the cost
of serializing claims per-queue.

## Idempotency

**Decision:** Optional `idempotency_key` on job creation, unique per
`(queue_id, idempotency_key)`. Recurring cron firings use a deterministic
generated key (`cron:{scheduled_job_id}:{fire_time}`) so the same firing can
never generate two jobs even if multiple scheduler replicas race.

**Why this is NOT exactly-once:** the idempotency key only prevents duplicate
*creation* of a job for the same logical request. It says nothing about
duplicate *execution* of an already-created job (see "at-least-once" above).
Both mechanisms are needed and solve different problems.

## Task sandboxing

**Decision:** Jobs reference a `task_name` resolved against a fixed,
developer-maintained registry (`app.tasks.registry`) rather than accepting
arbitrary code (e.g. a Python snippet) in the job payload.

**Why:** Accepting arbitrary code from API clients would mean remote code
execution on worker hosts by design. The registry pattern keeps the set of
possible operations fully auditable and reviewable ahead of time, at the cost
of requiring a code deploy to add new task types (an acceptable trade-off for
a production system).
