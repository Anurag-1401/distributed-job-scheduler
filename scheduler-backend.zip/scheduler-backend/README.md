# Distributed Job Scheduler — Backend

A production-inspired distributed background job scheduling platform built with
FastAPI, SQLAlchemy 2.x (async), PostgreSQL, Redis, and Alembic.

See `docs/` for full architecture, database, job-lifecycle, worker-design,
retry-strategy, and design-decision documentation with Mermaid diagrams.

## Quick start (Docker Compose)

```bash
cp .env.example .env   # edit JWT_SECRET_KEY at minimum
docker compose up --build
```

This starts PostgreSQL, Redis, runs Alembic migrations, and starts the API
(`:8000`), one worker, and the scheduler. Swagger UI: http://localhost:8000/docs

Scale workers:

```bash
docker compose up --scale worker=3
```

## Local development (without Docker)

```bash
cd backend
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt

# Requires a local PostgreSQL + Redis (see .env.example for expected URLs)
alembic upgrade head

uvicorn app.main:app --reload            # API
python -m app.workers.worker_main        # worker (separate terminal)
python -m app.scheduler.scheduler_main   # scheduler (separate terminal)
```

## Running tests

```bash
cd backend
pip install -r requirements.txt
pytest tests/unit tests/integration -v            # fast, SQLite-backed
TEST_DATABASE_URL=postgresql+asyncpg://scheduler:scheduler@localhost:5432/scheduler_test \
  pytest tests/concurrency -v                       # requires real PostgreSQL
```

The concurrency suite (`tests/concurrency/`) is the most important test
category in this project: it proves, against a real PostgreSQL instance with
real overlapping transactions, that (a) multiple concurrent workers can never
claim the same job, and (b) a queue's `concurrency_limit` is never exceeded.

## Example API walkthrough

```bash
# Register + login
curl -X POST localhost:8000/api/v1/auth/register -H 'Content-Type: application/json' \
  -d '{"email":"me@example.com","password":"supersecret1","name":"Me"}'

TOKEN=<access_token from response>

# Create org -> project -> queue -> job
curl -X POST localhost:8000/api/v1/organizations -H "Authorization: Bearer $TOKEN" \
  -H 'Content-Type: application/json' -d '{"name":"Acme"}'
```

Full endpoint list is available via Swagger UI (`/docs`) once the API is running.

## Repository layout

```
backend/
├── app/            # application code (see docs/architecture.md)
├── alembic/        # database migrations
├── tests/          # unit / integration / concurrency test suites
├── requirements.txt
└── Dockerfile
docs/               # architecture & design documentation
docker-compose.yml
.env.example
```
